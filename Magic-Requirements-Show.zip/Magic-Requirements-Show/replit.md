# PolyLearn - Multi-Agent Collaborative Discussion Platform

## Overview
A multi-agent collaborative discussion platform where users create "rooms" with multiple AI agents that have distinct personalities. Users chat with agents via @mentions, agents respond using OpenAI via Replit AI Integrations.

## Architecture
- **Frontend**: React + Vite + Tailwind CSS + shadcn/ui
- **Backend**: Express.js with PostgreSQL database + OpenAI proxy route
- **Database**: PostgreSQL via Drizzle ORM (rooms, agents, messages, room_users tables)
- **AI**: OpenAI gpt-4o-mini via Replit AI Integrations (no API key required)
- **State**: Server-persisted via REST API, client-side React state for UI

## Design System
- Editorial theme: border-radius 0rem, no shadows, tracking-tight text, font-serif headings
- Accent color: hsl(0, 70%, 55%)
- Light theme default, dark mode toggle available
- Icons: react-icons/fi only

## Key Files
- `client/src/pages/agent-room.tsx` - Main page with all components (UserIdentityEntry, DashboardView, RoomConfigView, DiscussionView)
- `client/src/lib/aiAgent.ts` - AI agent calling function (proxied through backend)
- `server/routes.ts` - Backend API routes for rooms CRUD + OpenAI chat proxy
- `server/storage.ts` - Database storage interface and implementation
- `server/db.ts` - Drizzle ORM database connection
- `server/seed.ts` - Sample data seeder (runs on startup if DB is empty)
- `shared/schema.ts` - Drizzle schema definitions (rooms, agents, messages, roomUsers)
- `client/src/App.tsx` - App router

## Database Schema
- `rooms` - id, name, description, visibility, status, isTemplate, cloneCode, allowJoin, initialMessage, timerDuration, timerStartedAt, createdAt, lastActivity
- `agents` - id, roomId, name, systemPrompt, role (DB column: personality), description, temperature (x100), topP (x100), responseLength, trigger, frequency, interAgentRules, color, avatar
- `messages` - id, roomId, content, sender, senderType, agentId, timestamp, confidence (x100), tone, references (jsonb)
- `room_users` - id, roomId, name, email, role

## API Routes
- `GET /api/rooms` - List all rooms with agents, messages, users
- `GET /api/rooms/:id` - Get single room with agents, messages, users
- `POST /api/rooms` - Create room (accepts agents[] and users[] in body)
- `PUT /api/rooms/:id` - Update room (replaces agents/users if provided)
- `DELETE /api/rooms/:id` - Delete room and all related data
- `POST /api/rooms/:id/messages` - Add message to room
- `POST /api/chat` - Proxies to OpenAI, returns response with confidence/tone metadata

## Running
- `npm run dev` starts both Express backend and Vite frontend on port 5000
- Database auto-seeds with sample data on first startup

## Internationalization
- English and Arabic language support via `LanguageContext` + `useLanguage()` hook
- Translations defined as `EN` and `AR` objects at top of agent-room.tsx
- RTL layout applied automatically when Arabic is selected (`dir="rtl"` on `<html>`)
- Language persisted in `localStorage` under key `polylearn-lang`
- Toggle available: login screen (top-right globe button) + account dropdown menu

## User Preferences
- No toast/sonner notifications
- No sign-in or OAuth screens
- Emoji picker in chat (spec requirement)
- Admin passcode: admin123
