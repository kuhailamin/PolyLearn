import { db } from "./db";
import { rooms, agents, messages, roomUsers } from "@shared/schema";
import type { Room, Agent, Message, RoomUser, InsertRoom, InsertAgent, InsertMessage, InsertRoomUser } from "@shared/schema";
import { eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getRooms(): Promise<Room[]>;
  reorderRooms(order: { id: string; sortOrder: number }[]): Promise<void>;
  getRoom(id: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, data: Partial<InsertRoom>): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<void>;

  getAgentsByRoom(roomId: string): Promise<Agent[]>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgent(id: string, data: Partial<InsertAgent>): Promise<Agent | undefined>;
  deleteAgent(id: string): Promise<void>;
  deleteAgentsByRoom(roomId: string): Promise<void>;

  getMessagesByRoom(roomId: string): Promise<Message[]>;
  createMessage(msg: InsertMessage): Promise<Message>;

  getUsersByRoom(roomId: string): Promise<RoomUser[]>;
  createRoomUser(user: InsertRoomUser): Promise<RoomUser>;
  deleteRoomUsersByRoom(roomId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getRooms(): Promise<Room[]> {
    return db.select().from(rooms).orderBy(rooms.sortOrder);
  }

  async reorderRooms(order: { id: string; sortOrder: number }[]): Promise<void> {
    await Promise.all(
      order.map(({ id, sortOrder }) =>
        db.update(rooms).set({ sortOrder }).where(eq(rooms.id, id))
      )
    );
  }

  async getRoom(id: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room;
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const [created] = await db.insert(rooms).values({ ...room, id }).returning();
    return created;
  }

  async updateRoom(id: string, data: Partial<InsertRoom>): Promise<Room | undefined> {
    const [updated] = await db.update(rooms).set(data).where(eq(rooms.id, id)).returning();
    return updated;
  }

  async deleteRoom(id: string): Promise<void> {
    await db.delete(messages).where(eq(messages.roomId, id));
    await db.delete(agents).where(eq(agents.roomId, id));
    await db.delete(roomUsers).where(eq(roomUsers.roomId, id));
    await db.delete(rooms).where(eq(rooms.id, id));
  }

  async getAgentsByRoom(roomId: string): Promise<Agent[]> {
    return db.select().from(agents).where(eq(agents.roomId, roomId));
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const id = randomUUID();
    const [created] = await db.insert(agents).values({ ...agent, id }).returning();
    return created;
  }

  async updateAgent(id: string, data: Partial<InsertAgent>): Promise<Agent | undefined> {
    const [updated] = await db.update(agents).set(data).where(eq(agents.id, id)).returning();
    return updated;
  }

  async deleteAgent(id: string): Promise<void> {
    await db.delete(agents).where(eq(agents.id, id));
  }

  async deleteAgentsByRoom(roomId: string): Promise<void> {
    await db.delete(agents).where(eq(agents.roomId, roomId));
  }

  async getMessagesByRoom(roomId: string): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.roomId, roomId));
  }

  async createMessage(msg: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const [created] = await db.insert(messages).values({ ...msg, id }).returning();
    return created;
  }

  async getUsersByRoom(roomId: string): Promise<RoomUser[]> {
    return db.select().from(roomUsers).where(eq(roomUsers.roomId, roomId));
  }

  async createRoomUser(user: InsertRoomUser): Promise<RoomUser> {
    const id = randomUUID();
    const [created] = await db.insert(roomUsers).values({ ...user, id }).returning();
    return created;
  }

  async deleteRoomUsersByRoom(roomId: string): Promise<void> {
    await db.delete(roomUsers).where(eq(roomUsers.roomId, roomId));
  }
}

export const storage = new DatabaseStorage();
