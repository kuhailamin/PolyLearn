import { storage } from "./storage";

const AGENT_COLORS = [
  'hsl(0, 70%, 55%)',
  'hsl(210, 70%, 55%)',
  'hsl(150, 70%, 45%)',
  'hsl(280, 65%, 55%)',
  'hsl(35, 80%, 50%)',
  'hsl(330, 70%, 55%)',
];

const ago = (mins: number) => new Date(Date.now() - mins * 60000).toISOString();

export async function seedIfEmpty() {
  const existing = await storage.getRooms();
  if (existing.length > 0) return;

  const room1 = await storage.createRoom({
    name: 'Product Strategy Review',
    description: 'Quarterly product strategy review with AI advisors',
    visibility: 'private', status: 'active', isTemplate: false,
    cloneCode: 'strategy2024', allowJoin: true, initialMessage: '',
    timerDuration: 15, timerStartedAt: null,
    createdAt: ago(1440), lastActivity: ago(15),
  });

  const agents1 = [
    { name: 'ResearchAnalyst', systemPrompt: 'You are a research analyst. Provide data-driven insights and market analysis.', role: 'analytical', description: 'Provides data-driven insights and market analysis to ground the discussion in evidence.', temperature: 30, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[0], avatar: '' },
    { name: 'CreativeDirector', systemPrompt: 'You are a creative director. Suggest innovative ideas and creative approaches.', role: 'creative', description: 'Brings imaginative thinking and unconventional ideas to spark new directions.', temperature: 80, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[1], avatar: '' },
    { name: 'DevilsAdvocate', systemPrompt: "You are a devil's advocate. Challenge assumptions and point out potential flaws.", role: 'critic', description: 'Challenges assumptions and stress-tests ideas to surface hidden weaknesses.', temperature: 60, topP: 90, responseLength: 'short', trigger: 'mentions', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[2], avatar: '' },
  ];
  for (const a of agents1) {
    await storage.createAgent({ ...a, roomId: room1.id });
  }
  await storage.createRoomUser({ roomId: room1.id, name: 'Sarah Chen', email: 'sarah@example.com', role: 'moderator' });
  await storage.createRoomUser({ roomId: room1.id, name: 'Marcus Webb', email: 'marcus@example.com', role: 'participant' });

  await storage.createMessage({
    roomId: room1.id, content: "Let's discuss our Q2 product roadmap. What should we prioritize?",
    sender: 'Sarah Chen', senderType: 'user', agentId: null, timestamp: ago(30),
    confidence: null, tone: null, references: null,
  });
  await storage.createMessage({
    roomId: room1.id,
    content: 'Based on current market trends, I recommend focusing on **mobile-first experiences**. Our analytics show a 40% increase in mobile traffic over the past quarter.\n\n- User engagement on mobile is 2.3x higher\n- Conversion rates have improved by 15%\n- Competitor analysis shows a clear gap we can exploit',
    sender: 'ResearchAnalyst', senderType: 'agent', agentId: '', timestamp: ago(28),
    confidence: 89, tone: 'analytical', references: ['Q1 Analytics Report'],
  });
  await storage.createMessage({
    roomId: room1.id,
    content: 'What if we went beyond just mobile-first? Imagine an **AI-powered personalization engine** that adapts the entire experience in real-time.\n\n1. Dynamic content based on user behavior\n2. Predictive recommendations\n3. Context-aware UI adjustments',
    sender: 'CreativeDirector', senderType: 'agent', agentId: '', timestamp: ago(25),
    confidence: 76, tone: 'creative', references: null,
  });

  const room2 = await storage.createRoom({
    name: 'Tech Architecture Planning',
    description: 'System architecture discussion for the new platform',
    visibility: 'public', status: 'active', isTemplate: false,
    cloneCode: 'techarch99', allowJoin: true, initialMessage: '',
    timerDuration: 15, timerStartedAt: null,
    createdAt: ago(2880), lastActivity: ago(60),
  });
  await storage.createAgent({ roomId: room2.id, name: 'SecurityExpert', systemPrompt: 'You are a cybersecurity expert. Evaluate security implications of every decision.', role: 'analyst', description: 'Evaluates every decision through a security lens to identify risks and vulnerabilities.', temperature: 20, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[3], avatar: 'agent-face-1' });
  await storage.createAgent({ roomId: room2.id, name: 'CostOptimizer', systemPrompt: 'You are a cost optimization specialist. Analyze cost-benefit of architectural decisions.', role: 'analytical', description: 'Analyzes the cost-benefit tradeoffs of every architectural choice.', temperature: 30, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[4], avatar: '' });
  await storage.createRoomUser({ roomId: room2.id, name: 'Alex Turner', email: 'alex@example.com', role: 'moderator' });

  const room3 = await storage.createRoom({
    name: 'Marketing Campaign Brainstorm',
    description: 'Creative brainstorming for Q3 marketing campaign',
    visibility: 'public', status: 'active', isTemplate: false,
    cloneCode: 'brand2024', allowJoin: true, initialMessage: '',
    timerDuration: 15, timerStartedAt: null,
    createdAt: ago(720), lastActivity: ago(120),
  });
  await storage.createAgent({ roomId: room3.id, name: 'BrandStrategist', systemPrompt: 'You are a brand strategist. Focus on brand consistency and market positioning.', role: 'supportive', description: 'Keeps the team anchored to brand identity and strategic positioning.', temperature: 50, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[5], avatar: 'agent-face-3' });
  await storage.createRoomUser({ roomId: room3.id, name: 'Jamie Ross', email: 'jamie@example.com', role: 'participant' });

  const room4 = await storage.createRoom({
    name: 'Customer Support Team',
    description: 'Template for customer support discussion rooms with empathy-focused agents',
    visibility: 'public', status: 'active', isTemplate: true,
    cloneCode: '', allowJoin: true, initialMessage: '',
    timerDuration: 15, timerStartedAt: null,
    createdAt: ago(4320), lastActivity: ago(4320),
  });
  await storage.createAgent({ roomId: room4.id, name: 'EmpathyResponder', systemPrompt: 'You are an empathetic support agent. Respond with care and understanding.', role: 'supportive', description: 'Responds with warmth and care, ensuring users feel heard and supported.', temperature: 40, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[0], avatar: 'face-2' });
  await storage.createAgent({ roomId: room4.id, name: 'KnowledgeExpert', systemPrompt: 'You are a knowledge base expert. Provide accurate technical information.', role: 'analytical', description: 'Delivers accurate, detailed technical information from the knowledge base.', temperature: 20, topP: 90, responseLength: 'long', trigger: 'mentions', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[1], avatar: 'agent-face-5' });

  const room5 = await storage.createRoom({
    name: 'Debate Forum',
    description: 'Template for structured debates with pro/con agents and a moderator',
    visibility: 'public', status: 'active', isTemplate: true,
    cloneCode: '', allowJoin: true, initialMessage: '',
    timerDuration: 15, timerStartedAt: null,
    createdAt: ago(4320), lastActivity: ago(4320),
  });
  await storage.createAgent({ roomId: room5.id, name: 'ProAdvocate', systemPrompt: 'You argue in favor of the topic. Present strong supporting arguments.', role: 'formal', description: 'Argues strongly in favor of the topic with structured, compelling reasoning.', temperature: 50, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[2], avatar: 'face-8' });
  await storage.createAgent({ roomId: room5.id, name: 'ConCritic', systemPrompt: 'You argue against the topic. Present strong counterarguments.', role: 'critic', description: 'Presents the strongest counterarguments and exposes flaws in the opposing case.', temperature: 50, topP: 90, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[3], avatar: 'face-5' });
  await storage.createAgent({ roomId: room5.id, name: 'DebateModerator', systemPrompt: 'You moderate the debate. Summarize key points and ensure fair discussion.', role: 'facilitator', description: 'Keeps the debate structured, fair, and on track by summarizing and mediating.', temperature: 30, topP: 90, responseLength: 'medium', trigger: 'proactive', frequency: 'every-2nd', interAgentRules: 'reference', color: AGENT_COLORS[4], avatar: 'agent-face-7' });

  console.log("Database seeded with sample data");
}
