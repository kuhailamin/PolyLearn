import type { Express } from "express";
import { createServer, type Server } from "http";
import OpenAI from "openai";
import { storage } from "./storage";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/chat", async (req, res) => {
    try {
      const { systemPrompt, messages, prompt, session_id, agentName } = req.body;

      const chatMessages: { role: "system" | "user" | "assistant"; content: string }[] = [];

      if (systemPrompt) {
        chatMessages.push({ role: "system", content: systemPrompt });
      }

      if (messages && Array.isArray(messages)) {
        for (const m of messages) {
          chatMessages.push({ role: m.role, content: m.content });
        }
      } else if (prompt) {
        chatMessages.push({ role: "user", content: prompt });
      }

      if (chatMessages.length === 0) {
        return res.status(400).json({ error: "No messages provided" });
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: chatMessages,
        max_tokens: 1024,
      });

      let content = response.choices[0]?.message?.content || "";

      if (agentName && content) {
        const escapedName = agentName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        content = content.trim().replace(new RegExp(`^${escapedName}\\s*:\\s*`, 'i'), '');
      }

      const confidence = 0.7 + Math.random() * 0.25;
      const tones = ["analytical", "creative", "formal", "casual", "supportive", "provocative"];
      const tone = tones[Math.floor(Math.random() * tones.length)];

      res.json({
        response: content,
        text: content,
        content: content,
        confidence,
        tone,
        references: [],
      });
    } catch (error: any) {
      console.error("Chat API error:", error?.message || error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  app.get("/api/rooms", async (_req, res) => {
    try {
      const allRooms = await storage.getRooms();
      const result = await Promise.all(
        allRooms.map(async (room) => {
          const roomAgents = await storage.getAgentsByRoom(room.id);
          const roomMessages = await storage.getMessagesByRoom(room.id);
          const roomUsersList = await storage.getUsersByRoom(room.id);
          return {
            ...room,
            agents: roomAgents.map(a => ({
              ...a,
              temperature: a.temperature / 100,
              topP: a.topP / 100,
            })),
            messages: roomMessages.map(m => ({
              ...m,
              confidence: m.confidence !== null ? m.confidence / 100 : undefined,
              references: m.references || [],
            })),
            users: roomUsersList,
          };
        })
      );
      res.json(result);
    } catch (error: any) {
      console.error("Get rooms error:", error?.message || error);
      res.status(500).json({ error: "Failed to fetch rooms" });
    }
  });

  app.get("/api/rooms/:id", async (req, res) => {
    try {
      const room = await storage.getRoom(req.params.id);
      if (!room) return res.status(404).json({ error: "Room not found" });
      const roomAgents = await storage.getAgentsByRoom(room.id);
      const roomMessages = await storage.getMessagesByRoom(room.id);
      const roomUsersList = await storage.getUsersByRoom(room.id);
      res.json({
        ...room,
        agents: roomAgents.map(a => ({
          ...a,
          temperature: a.temperature / 100,
          topP: a.topP / 100,
        })),
        messages: roomMessages.map(m => ({
          ...m,
          confidence: m.confidence !== null ? m.confidence / 100 : undefined,
          references: m.references || [],
        })),
        users: roomUsersList,
      });
    } catch (error: any) {
      console.error("Get room error:", error?.message || error);
      res.status(500).json({ error: "Failed to fetch room" });
    }
  });

  app.put("/api/rooms/reorder", async (req, res) => {
    try {
      const { order } = req.body;
      if (!Array.isArray(order)) return res.status(400).json({ error: "order must be an array" });
      await storage.reorderRooms(order);
      res.json({ ok: true });
    } catch (error: any) {
      console.error("Reorder rooms error:", error?.message || error);
      res.status(500).json({ error: "Failed to reorder rooms" });
    }
  });

  app.post("/api/rooms", async (req, res) => {
    try {
      const { agents: agentsList, users: usersList, ...roomData } = req.body;
      const room = await storage.createRoom(roomData);
      if (agentsList && Array.isArray(agentsList)) {
        for (const agent of agentsList) {
          await storage.createAgent({
            ...agent,
            roomId: room.id,
            temperature: Math.round((agent.temperature ?? 0.5) * 100),
            topP: Math.round((agent.topP ?? 0.9) * 100),
          });
        }
      }
      if (usersList && Array.isArray(usersList)) {
        for (const user of usersList) {
          await storage.createRoomUser({ ...user, roomId: room.id });
        }
      }
      const roomAgents = await storage.getAgentsByRoom(room.id);
      const roomUsersFull = await storage.getUsersByRoom(room.id);
      res.json({
        ...room,
        agents: roomAgents.map(a => ({
          ...a,
          temperature: a.temperature / 100,
          topP: a.topP / 100,
        })),
        messages: [],
        users: roomUsersFull,
      });
    } catch (error: any) {
      console.error("Create room error:", error?.message || error);
      res.status(500).json({ error: "Failed to create room" });
    }
  });

  app.put("/api/rooms/:id", async (req, res) => {
    try {
      const { agents: agentsList, users: usersList, messages: msgList, ...roomData } = req.body;
      const updated = await storage.updateRoom(req.params.id, roomData);
      if (!updated) return res.status(404).json({ error: "Room not found" });

      if (agentsList && Array.isArray(agentsList)) {
        await storage.deleteAgentsByRoom(updated.id);
        for (const agent of agentsList) {
          const { id: _agentId, ...agentData } = agent;
          await storage.createAgent({
            ...agentData,
            roomId: updated.id,
            temperature: Math.round((agent.temperature ?? 0.5) * 100),
            topP: Math.round((agent.topP ?? 0.9) * 100),
          });
        }
      }

      if (usersList && Array.isArray(usersList)) {
        await storage.deleteRoomUsersByRoom(updated.id);
        for (const user of usersList) {
          const { id: _userId, ...userData } = user;
          await storage.createRoomUser({ ...userData, roomId: updated.id });
        }
      }

      const roomAgents = await storage.getAgentsByRoom(updated.id);
      const roomMessages = await storage.getMessagesByRoom(updated.id);
      const roomUsersFull = await storage.getUsersByRoom(updated.id);
      res.json({
        ...updated,
        agents: roomAgents.map(a => ({
          ...a,
          temperature: a.temperature / 100,
          topP: a.topP / 100,
        })),
        messages: roomMessages.map(m => ({
          ...m,
          confidence: m.confidence !== null ? m.confidence / 100 : undefined,
          references: m.references || [],
        })),
        users: roomUsersFull,
      });
    } catch (error: any) {
      console.error("Update room error:", error?.message || error);
      res.status(500).json({ error: "Failed to update room" });
    }
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      await storage.deleteRoom(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Delete room error:", error?.message || error);
      res.status(500).json({ error: "Failed to delete room" });
    }
  });

  app.post("/api/rooms/:id/messages", async (req, res) => {
    try {
      const roomId = req.params.id;
      const { content, sender, senderType, agentId, confidence, tone, references } = req.body;
      const msg = await storage.createMessage({
        roomId,
        content,
        sender,
        senderType: senderType || "user",
        agentId: agentId || null,
        timestamp: new Date().toISOString(),
        confidence: confidence !== undefined ? Math.round(confidence * 100) : null,
        tone: tone || null,
        references: references || null,
      });
      await storage.updateRoom(roomId, { lastActivity: new Date().toISOString() });
      res.json({
        ...msg,
        confidence: msg.confidence !== null ? msg.confidence / 100 : undefined,
        references: msg.references || [],
      });
    } catch (error: any) {
      console.error("Create message error:", error?.message || error);
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  return httpServer;
}
