import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  visibility: text("visibility").notNull().default("public"),
  status: text("status").notNull().default("active"),
  isTemplate: boolean("is_template").notNull().default(false),
  cloneCode: text("clone_code").notNull().default(""),
  allowJoin: boolean("allow_join").notNull().default(true),
  initialMessage: text("initial_message").notNull().default(""),
  timerDuration: integer("timer_duration").notNull().default(15),
  timerStartedAt: text("timer_started_at"),
  createdAt: text("created_at").notNull().default(sql`now()::text`),
  lastActivity: text("last_activity").notNull().default(sql`now()::text`),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const agents = pgTable("agents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull(),
  name: text("name").notNull(),
  systemPrompt: text("system_prompt").notNull().default(""),
  role: text("personality").notNull().default("analytical"),
  description: text("description").notNull().default(""),
  temperature: integer("temperature_x100").notNull().default(50),
  topP: integer("top_p_x100").notNull().default(90),
  responseLength: text("response_length").notNull().default("medium"),
  trigger: text("trigger").notNull().default("all"),
  frequency: text("frequency").notNull().default("every-message"),
  interAgentRules: text("inter_agent_rules").notNull().default("reference"),
  color: text("color").notNull().default("hsl(0, 70%, 55%)"),
  avatar: text("avatar").notNull().default(""),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull(),
  content: text("content").notNull(),
  sender: text("sender").notNull(),
  senderType: text("sender_type").notNull().default("user"),
  agentId: text("agent_id"),
  timestamp: text("timestamp").notNull().default(sql`now()::text`),
  confidence: integer("confidence_x100"),
  tone: text("tone"),
  references: jsonb("references").$type<string[]>(),
});

export const roomUsers = pgTable("room_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().default(""),
  role: text("role").notNull().default("participant"),
});

export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true });
export const insertAgentSchema = createInsertSchema(agents).omit({ id: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true });
export const insertRoomUserSchema = createInsertSchema(roomUsers).omit({ id: true });

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertRoomUser = z.infer<typeof insertRoomUserSchema>;
export type RoomUser = typeof roomUsers.$inferSelect;
