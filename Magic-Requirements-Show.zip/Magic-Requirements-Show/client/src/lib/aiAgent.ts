export async function callAIAgent(
  systemPrompt: string,
  userMessages: { role: 'user' | 'assistant'; content: string }[],
  options: { session_id: string; agentName?: string }
): Promise<any> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemPrompt, messages: userMessages, session_id: options.session_id, agentName: options.agentName }),
  })
  if (!res.ok) {
    throw new Error(`Agent call failed: ${res.status}`)
  }
  return res.json()
}
