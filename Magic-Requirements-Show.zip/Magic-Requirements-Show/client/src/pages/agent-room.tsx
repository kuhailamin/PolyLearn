import { useState, useEffect, useRef, useCallback, createContext, useContext } from 'react'
import { callAIAgent } from '@/lib/aiAgent'
import { cn, generateUUID } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu'
import {
  FiPlus, FiSettings, FiUsers, FiSend, FiMessageSquare, FiSearch,
  FiTrash2, FiArrowLeft, FiChevronDown, FiChevronUp, FiActivity,
  FiCpu, FiUser, FiHash, FiLock, FiGlobe, FiArchive, FiX, FiZap,
  FiEdit3, FiLogIn, FiAlertCircle, FiShield, FiUserCheck, FiSmile,
  FiClock, FiCopy, FiKey, FiSun, FiMoon, FiStar, FiHeart, FiEye,
  FiBookOpen, FiCode, FiFeather, FiThumbsUp, FiThumbsDown, FiMic, FiLayout,
  FiLogOut, FiMenu
} from 'react-icons/fi'


type Lang = 'en' | 'ar'
type Translations = typeof EN
const EN = {
  appName: 'PolyLearn',
  activeRooms: 'Active Rooms',
  templates: 'Templates',
  createRoom: 'Create Room',
  searchPlaceholder: 'Search rooms...',
  agents: 'agents',
  users: 'users',
  noActiveRooms: 'No active rooms yet',
  noTemplates: 'No templates available',
  template: 'Template',
  clone: 'Clone',
  history: 'History',
  configure: 'Configure',
  delete: 'Delete',
  back: 'Back',
  save: 'Save',
  cancel: 'Cancel',
  launch: 'Launch Room',
  send: 'Send',
  logOut: 'Log Out',
  darkMode: 'Dark Mode',
  lightMode: 'Light Mode',
  arabic: 'العربية',
  english: 'English',
  switchToArabic: 'Switch to Arabic',
  switchToEnglish: 'Switch to English',
  admin: 'admin',
  participant: 'participant',
  roomName: 'Room Name',
  description: 'Description',
  createAsTemplate: 'Create as Template',
  enterRoomName: 'Enter room name',
  whatsThisRoomAbout: "What's this room about?",
  createRoomTitle: 'Create Room',
  setupNewRoom: 'Set up a new discussion room',
  confirmCreate: 'Create',
  cloneRoom: 'Clone Room',
  cloneRoomDesc: 'Create a copy of this room',
  cloneCode: 'Clone Code (optional)',
  confirmClone: 'Clone',
  deleteRoom: 'Delete Room',
  deleteConfirm: 'This will permanently delete the room and all its messages. This cannot be undone.',
  confirmDelete: 'Delete',
  roomHistory: 'Room History',
  noMessages: 'No messages yet',
  typeMessage: 'Type a message...',
  you: 'You',
  addAgent: 'Add Agent',
  agentName: 'Agent Name',
  role: 'Role',
  systemPrompt: 'System Prompt',
  temperature: 'Temperature',
  responseLength: 'Response Length',
  trigger: 'Trigger',
  frequency: 'Frequency',
  color: 'Color',
  avatar: 'Avatar',
  visibility: 'Visibility',
  publicRoom: 'Public',
  privateRoom: 'Private',
  status: 'Status',
  active: 'Active',
  closed: 'Closed',
  timerDuration: 'Timer Duration',
  initialMessage: 'Initial Message',
  allowJoin: 'Allow Join',
  roomSettings: 'Room Settings',
  agentSettings: 'Agent Settings',
  discussion: 'Discussion',
  enterYourName: 'Enter your name',
  passcode: 'Admin Passcode',
  joinAs: 'Join as',
  joinBtn: 'Enter',
  wrongPasscode: 'Wrong passcode',
  welcomeTo: 'Welcome to',
  platformDesc: 'Multi-agent collaborative discussion platform',
  cloneTemplate: 'Use Template',
  minutes: 'minutes',
  timerExpired: 'Timer expired',
  copyCode: 'Copy Code',
  leaveRoom: 'Leave Room',
  roomCode: 'Room Code',
  enterRoomCode: 'Enter room code',
  joinRoom: 'Join Room',
  or: 'or',
  createdAt: 'Created',
  lastActivity: 'Last activity',
}

const AR: Translations = {
  appName: 'بولي ليرن',
  activeRooms: 'الغرف النشطة',
  templates: 'القوالب',
  createRoom: 'إنشاء غرفة',
  searchPlaceholder: 'ابحث عن الغرف...',
  agents: 'وكلاء',
  users: 'مستخدمون',
  noActiveRooms: 'لا توجد غرف نشطة بعد',
  noTemplates: 'لا توجد قوالب متاحة',
  template: 'قالب',
  clone: 'نسخ',
  history: 'السجل',
  configure: 'إعداد',
  delete: 'حذف',
  back: 'رجوع',
  save: 'حفظ',
  cancel: 'إلغاء',
  launch: 'إطلاق الغرفة',
  send: 'إرسال',
  logOut: 'تسجيل الخروج',
  darkMode: 'الوضع الداكن',
  lightMode: 'الوضع الفاتح',
  arabic: 'العربية',
  english: 'English',
  switchToArabic: 'التبديل إلى العربية',
  switchToEnglish: 'Switch to English',
  admin: 'مشرف',
  participant: 'مشارك',
  roomName: 'اسم الغرفة',
  description: 'الوصف',
  createAsTemplate: 'إنشاء كقالب',
  enterRoomName: 'أدخل اسم الغرفة',
  whatsThisRoomAbout: 'ما موضوع هذه الغرفة؟',
  createRoomTitle: 'إنشاء غرفة',
  setupNewRoom: 'قم بإعداد غرفة نقاش جديدة',
  confirmCreate: 'إنشاء',
  cloneRoom: 'نسخ الغرفة',
  cloneRoomDesc: 'إنشاء نسخة من هذه الغرفة',
  cloneCode: 'رمز النسخ (اختياري)',
  confirmClone: 'نسخ',
  deleteRoom: 'حذف الغرفة',
  deleteConfirm: 'سيؤدي هذا إلى حذف الغرفة وجميع رسائلها نهائياً. لا يمكن التراجع عن هذا الإجراء.',
  confirmDelete: 'حذف',
  roomHistory: 'سجل الغرفة',
  noMessages: 'لا توجد رسائل بعد',
  typeMessage: 'اكتب رسالة...',
  you: 'أنت',
  addAgent: 'إضافة وكيل',
  agentName: 'اسم الوكيل',
  role: 'الدور',
  systemPrompt: 'موجه النظام',
  temperature: 'درجة الحرارة',
  responseLength: 'طول الرد',
  trigger: 'المحفز',
  frequency: 'التكرار',
  color: 'اللون',
  avatar: 'الصورة الرمزية',
  visibility: 'الظهور',
  publicRoom: 'عام',
  privateRoom: 'خاص',
  status: 'الحالة',
  active: 'نشط',
  closed: 'مغلق',
  timerDuration: 'مدة المؤقت',
  initialMessage: 'الرسالة الأولى',
  allowJoin: 'السماح بالانضمام',
  roomSettings: 'إعدادات الغرفة',
  agentSettings: 'إعدادات الوكلاء',
  discussion: 'النقاش',
  enterYourName: 'أدخل اسمك',
  passcode: 'رمز المشرف',
  joinAs: 'انضم بوصفك',
  joinBtn: 'دخول',
  wrongPasscode: 'رمز مرور خاطئ',
  welcomeTo: 'مرحباً بك في',
  platformDesc: 'منصة نقاش تعاوني متعدد الوكلاء',
  cloneTemplate: 'استخدام القالب',
  minutes: 'دقائق',
  timerExpired: 'انتهى المؤقت',
  copyCode: 'نسخ الرمز',
  leaveRoom: 'مغادرة الغرفة',
  roomCode: 'رمز الغرفة',
  enterRoomCode: 'أدخل رمز الغرفة',
  joinRoom: 'الانضمام إلى الغرفة',
  or: 'أو',
  createdAt: 'تاريخ الإنشاء',
  lastActivity: 'آخر نشاط',
}

const TRANSLATIONS: Record<Lang, Translations> = { en: EN, ar: AR }
const LanguageContext = createContext<{ lang: Lang; t: Translations }>({ lang: 'en', t: EN })
const useLanguage = () => useContext(LanguageContext)

const AGENT_COLORS = [
  'hsl(0, 70%, 55%)',
  'hsl(210, 70%, 55%)',
  'hsl(150, 70%, 45%)',
  'hsl(280, 65%, 55%)',
  'hsl(35, 80%, 50%)',
  'hsl(330, 70%, 55%)',
]

const ROLES = ['formal', 'casual', 'provocative', 'supportive', 'analytical', 'creative', 'pragmatic', 'reflector', 'architect', 'challenger', 'reframer', 'analyst', 'critic', 'brainstormer', 'facilitator']
const RESPONSE_LENGTHS = ['short', 'medium', 'long', 'unlimited']
const FREQUENCIES = ['every-message', 'every-2nd', 'every-3rd', 'cooldown-30s']
const ADMIN_PASSCODE = 'admin123'

const EMOJI_CATEGORIES = [
  { name: 'Smileys', emojis: ['\u{1F600}','\u{1F603}','\u{1F604}','\u{1F601}','\u{1F606}','\u{1F605}','\u{1F602}','\u{1F60A}','\u{1F607}','\u{1F642}','\u{1F643}','\u{1F609}'] },
  { name: 'Gestures', emojis: ['\u{1F44D}','\u{1F44E}','\u{1F44F}','\u{1F64C}','\u{1F64F}','\u{1F91D}','\u{270C}\u{FE0F}','\u{1F91E}','\u{1F4AA}','\u{1F44B}','\u{1F44C}','\u{270B}'] },
  { name: 'Objects', emojis: ['\u{1F4A1}','\u{1F525}','\u{2B50}','\u{1F4AF}','\u{1F3AF}','\u{1F680}','\u{1F4DD}','\u{1F4DA}','\u{1F4BB}','\u{1F50D}','\u{1F4CC}','\u{1F4CA}'] },
  { name: 'Reactions', emojis: ['\u{2764}\u{FE0F}','\u{1F499}','\u{1F49A}','\u{1F49B}','\u{1F49C}','\u{1F9E1}','\u{1F4AB}','\u{1F389}','\u{1F388}','\u{1F381}','\u{1F3C6}','\u{1F451}'] },
]

interface CartoonFace {
  id: string
  label: string
  svgFn: (s: number) => JSX.Element
}

function _f(s: number, bg: string, skin: string, hairFn: (s: number, cx: number, cy: number, r: number) => JSX.Element | null, eyeFn: (s: number, cx: number, cy: number, r: number) => JSX.Element, mouthFn: (s: number, cx: number, cy: number, r: number) => JSX.Element, extrasFn?: (s: number, cx: number, cy: number, r: number) => JSX.Element | null) {
  const cx = s / 2, cy = s * 0.52, r = s * 0.34
  const neckW = r * 0.5, neckH = r * 0.3
  const shoulderW = s * 0.48, shoulderH = s * 0.22
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{ display: 'block' }}>
      <rect width={s} height={s} fill={bg} />
      <ellipse cx={cx} cy={s + shoulderH * 0.1} rx={shoulderW} ry={shoulderH} fill={skin} opacity={0.5} />
      <rect x={cx - neckW / 2} y={cy + r * 0.85} width={neckW} height={neckH} fill={skin} />
      {hairFn(s, cx, cy, r)}
      <ellipse cx={cx} cy={cy} rx={r} ry={r * 1.05} fill={skin} />
      {eyeFn(s, cx, cy, r)}
      {mouthFn(s, cx, cy, r)}
      {extrasFn?.(s, cx, cy, r)}
    </svg>
  )
}

const _eyeDot = (s: number, cx: number, cy: number, r: number, col = '#2C1810') => {
  const ey = cy - r * 0.08, sp = r * 0.33, er = r * 0.07
  const brow = r * 0.04
  return <>
    <ellipse cx={cx - sp} cy={ey - r * 0.22} rx={er * 1.8} ry={brow} fill={col} opacity={0.6} />
    <ellipse cx={cx + sp} cy={ey - r * 0.22} rx={er * 1.8} ry={brow} fill={col} opacity={0.6} />
    <circle cx={cx - sp} cy={ey} r={er} fill={col} />
    <circle cx={cx + sp} cy={ey} r={er} fill={col} />
    <circle cx={cx - sp + er * 0.3} cy={ey - er * 0.3} r={er * 0.3} fill="#fff" opacity={0.7} />
    <circle cx={cx + sp + er * 0.3} cy={ey - er * 0.3} r={er * 0.3} fill="#fff" opacity={0.7} />
  </>
}

const _smile = (_s: number, cx: number, cy: number, r: number) => {
  const my = cy + r * 0.35
  return <path d={`M${cx - r * 0.22} ${my} Q${cx} ${my + r * 0.2} ${cx + r * 0.22} ${my}`} fill="none" stroke="#5C4033" strokeWidth={r * 0.06} strokeLinecap="round" />
}
const _grin = (_s: number, cx: number, cy: number, r: number) => {
  const my = cy + r * 0.32
  return <><path d={`M${cx - r * 0.28} ${my} Q${cx} ${my + r * 0.28} ${cx + r * 0.28} ${my}`} fill="#fff" stroke="#5C4033" strokeWidth={r * 0.05} /><line x1={cx - r * 0.15} y1={my + r * 0.03} x2={cx + r * 0.15} y2={my + r * 0.03} stroke="#E8E8E8" strokeWidth={r * 0.02} /></>
}
const _smirk = (_s: number, cx: number, cy: number, r: number) => {
  const my = cy + r * 0.35
  return <path d={`M${cx - r * 0.15} ${my + r * 0.02} Q${cx + r * 0.05} ${my + r * 0.15} ${cx + r * 0.2} ${my - r * 0.03}`} fill="none" stroke="#5C4033" strokeWidth={r * 0.06} strokeLinecap="round" />
}

const _glasses = (s: number, cx: number, cy: number, r: number) => {
  const ey = cy - r * 0.08, sp = r * 0.33, gr = r * 0.17, sw = s * 0.018
  return <>
    <rect x={cx - sp - gr} y={ey - gr} width={gr * 2} height={gr * 1.8} rx={gr * 0.3} fill="none" stroke="#444" strokeWidth={sw} />
    <rect x={cx + sp - gr} y={ey - gr} width={gr * 2} height={gr * 1.8} rx={gr * 0.3} fill="none" stroke="#444" strokeWidth={sw} />
    <line x1={cx - sp + gr} y1={ey} x2={cx + sp - gr} y2={ey} stroke="#444" strokeWidth={sw} />
    <line x1={cx - sp - gr} y1={ey} x2={cx - r * 0.85} y2={ey - r * 0.05} stroke="#444" strokeWidth={sw} />
    <line x1={cx + sp + gr} y1={ey} x2={cx + r * 0.85} y2={ey - r * 0.05} stroke="#444" strokeWidth={sw} />
  </>
}

const CARTOON_FACES: CartoonFace[] = [
  { id: 'face-1', label: 'Marcus', svgFn: (s) => _f(s, '#DCEEFB', '#8D5524', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.8} ry={r * 0.45} fill="#1A1110" /><rect x={cx - r * 0.7} y={cy - r * 0.6} width={r * 1.4} height={r * 0.2} fill="#1A1110" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.35} ${cy + r * 0.15} Q${cx - r * 0.3} ${cy + r * 0.55} ${cx} ${cy + r * 0.65} Q${cx + r * 0.3} ${cy + r * 0.55} ${cx + r * 0.35} ${cy + r * 0.15}`} fill="#1A1110" opacity={0.85} /><path d={`M${cx - r * 0.2} ${cy + r * 0.18} L${cx} ${cy + r * 0.25} L${cx + r * 0.2} ${cy + r * 0.18}`} fill="none" stroke="#1A1110" strokeWidth={r * 0.06} strokeLinecap="round" /></>) },
  { id: 'face-2', label: 'Priya', svgFn: (s) => _f(s, '#FDE8E0', '#C68642', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.9} ry={r * 0.55} fill="#0D0D0D" /><rect x={cx - r * 0.88} y={cy - r * 0.15} width={r * 0.28} height={r * 1.4} rx={r * 0.12} fill="#0D0D0D" /><rect x={cx + r * 0.6} y={cy - r * 0.15} width={r * 0.28} height={r * 1.4} rx={r * 0.12} fill="#0D0D0D" /><circle cx={cx} cy={cy - r * 0.32} r={r * 0.06} fill="#E53935" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <><circle cx={cx - r * 0.85} cy={cy + r * 0.15} r={r * 0.06} fill="#FFD700" /><circle cx={cx + r * 0.85} cy={cy + r * 0.15} r={r * 0.06} fill="#FFD700" /></>) },
  { id: 'face-3', label: 'Erik', svgFn: (s) => _f(s, '#E0F0E0', '#F5D0A9', (s, cx, cy, r) => <ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.75} ry={r * 0.42} fill="#D4A76A" />, (s, cx, cy, r) => <>{_eyeDot(s, cx, cy, r, '#4682B4')}{_glasses(s, cx, cy, r)}</>, (s, cx, cy, r) => _smirk(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.25} ${cy + r * 0.2} Q${cx} ${cy + r * 0.5} ${cx + r * 0.25} ${cy + r * 0.2}`} fill="#B8860B" opacity={0.7} /><rect x={cx - r * 0.18} y={cy + r * 0.18} width={r * 0.36} height={r * 0.08} fill="#B8860B" opacity={0.6} /></>) },
  { id: 'face-4', label: 'Amira', svgFn: (s) => _f(s, '#F0E6F6', '#D2A679', (s, cx, cy, r) => {
    return <><path d={`M${cx - r * 1.05} ${cy - r * 0.3} Q${cx - r * 1.1} ${cy - r * 1.3} ${cx} ${cy - r * 1.35} Q${cx + r * 1.1} ${cy - r * 1.3} ${cx + r * 1.05} ${cy - r * 0.3} L${cx + r * 1.0} ${cy + r * 0.9} Q${cx + r * 0.85} ${cy + r * 1.05} ${cx + r * 0.5} ${cy + r * 1.05} L${cx + r * 0.45} ${cy + r * 0.3} L${cx - r * 0.45} ${cy + r * 0.3} L${cx - r * 0.5} ${cy + r * 1.05} Q${cx - r * 0.85} ${cy + r * 1.05} ${cx - r * 1.0} ${cy + r * 0.9} Z`} fill="#7B5EA7" /><ellipse cx={cx} cy={cy - r * 0.35} rx={r * 0.65} ry={r * 0.15} fill="#9370DB" opacity={0.4} /></>
  }, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#3B2417'), (s, cx, cy, r) => _smile(s, cx, cy, r)) },
  { id: 'face-5', label: 'Tunde', svgFn: (s) => _f(s, '#FFF3E0', '#6F4E37', (s, cx, cy, r) => <circle cx={cx} cy={cy - r * 0.2} r={r * 1.05} fill="#0D0D0D" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _grin(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.3} ${cy + r * 0.2} Q${cx - r * 0.25} ${cy + r * 0.55} ${cx} ${cy + r * 0.6} Q${cx + r * 0.25} ${cy + r * 0.55} ${cx + r * 0.3} ${cy + r * 0.2}`} fill="#0D0D0D" opacity={0.8} /></>) },
  { id: 'face-6', label: 'Sofia', svgFn: (s) => _f(s, '#FCE4EC', '#FFE0BD', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.92} ry={r * 0.58} fill="#B55239" /><path d={`M${cx - r * 0.88} ${cy - r * 0.2} Q${cx - r * 0.75} ${cy + r * 0.5} ${cx - r * 0.45} ${cy + r * 0.8}`} stroke="#B55239" strokeWidth={r * 0.28} fill="none" strokeLinecap="round" /><path d={`M${cx + r * 0.88} ${cy - r * 0.2} Q${cx + r * 0.75} ${cy + r * 0.5} ${cx + r * 0.45} ${cy + r * 0.8}`} stroke="#B55239" strokeWidth={r * 0.28} fill="none" strokeLinecap="round" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2E8B57'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <>{[[cx - r * 0.25, cy + r * 0.18], [cx - r * 0.15, cy + r * 0.12], [cx - r * 0.35, cy + r * 0.12], [cx + r * 0.15, cy + r * 0.12], [cx + r * 0.25, cy + r * 0.18], [cx + r * 0.35, cy + r * 0.12]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={r * 0.025} fill="#C49A6C" />)}</>) },
  { id: 'face-7', label: 'Kenji', svgFn: (s) => _f(s, '#E3F2FD', '#FBECD4', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.8} ry={r * 0.45} fill="#1A1110" /><rect x={cx - r * 0.5} y={cy - r * 0.8} width={r * 1.0} height={r * 0.15} fill="#1A1110" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smirk(s, cx, cy, r)) },
  { id: 'face-8', label: 'Omar', svgFn: (s) => _f(s, '#E8EAF6', '#D2A679', (s, cx, cy, r) => <ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.78} ry={r * 0.42} fill="#1A1110" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#3B2417'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.28} ${cy + r * 0.18} Q${cx - r * 0.2} ${cy + r * 0.6} ${cx} ${cy + r * 0.7} Q${cx + r * 0.2} ${cy + r * 0.6} ${cx + r * 0.28} ${cy + r * 0.18}`} fill="#1A1110" opacity={0.85} /><rect x={cx - r * 0.22} y={cy + r * 0.18} width={r * 0.44} height={r * 0.08} fill="#1A1110" opacity={0.7} /></>) },
  { id: 'face-9', label: 'Aisha', svgFn: (s) => _f(s, '#F3E5F5', '#C68642', (s, cx, cy, r) => {
    return <><path d={`M${cx - r * 1.1} ${cy - r * 0.15} Q${cx - r * 1.15} ${cy - r * 1.35} ${cx} ${cy - r * 1.4} Q${cx + r * 1.15} ${cy - r * 1.35} ${cx + r * 1.1} ${cy - r * 0.15} Q${cx + r * 1.0} ${cy + r * 1.1} ${cx} ${cy + r * 1.15} Q${cx - r * 1.0} ${cy + r * 1.1} ${cx - r * 1.1} ${cy - r * 0.15} Z`} fill="#2196F3" /><ellipse cx={cx} cy={cy - r * 0.35} rx={r * 0.7} ry={r * 0.12} fill="#1976D2" opacity={0.5} /></>
  }, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r)) },
  { id: 'face-10', label: 'Chen', svgFn: (s) => _f(s, '#E0F7FA', '#F1C27D', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.82} ry={r * 0.48} fill="#2F1B14" /><rect x={cx - r * 0.3} y={cy - r * 0.85} width={r * 0.6} height={r * 0.2} fill="#2F1B14" /></>, (s, cx, cy, r) => <>{_eyeDot(s, cx, cy, r, '#3B2417')}{_glasses(s, cx, cy, r)}</>, (s, cx, cy, r) => _grin(s, cx, cy, r)) },
  { id: 'face-11', label: 'Lena', svgFn: (s) => _f(s, '#FFF9C4', '#FFE0BD', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.48} rx={r * 0.88} ry={r * 0.55} fill="#FFD700" /><rect x={cx - r * 0.85} y={cy - r * 0.15} width={r * 0.25} height={r * 1.0} rx={r * 0.1} fill="#FFD700" /><rect x={cx + r * 0.6} y={cy - r * 0.15} width={r * 0.25} height={r * 1.0} rx={r * 0.1} fill="#FFD700" /><path d={`M${cx - r * 0.65} ${cy - r * 0.7} Q${cx - r * 0.3} ${cy - r * 0.9} ${cx} ${cy - r * 0.85} Q${cx + r * 0.3} ${cy - r * 0.9} ${cx + r * 0.65} ${cy - r * 0.7}`} fill="none" stroke="#FFD700" strokeWidth={r * 0.15} /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#4169E1'), (s, cx, cy, r) => _grin(s, cx, cy, r), (s, cx, cy, r) => <><circle cx={cx - r * 0.38} cy={cy + r * 0.2} r={r * 0.1} fill="rgba(255,150,150,0.3)" /><circle cx={cx + r * 0.38} cy={cy + r * 0.2} r={r * 0.1} fill="rgba(255,150,150,0.3)" /></>) },
  { id: 'face-12', label: 'Diego', svgFn: (s) => _f(s, '#EFEBE9', '#E0AC69', (s, cx, cy, r) => <ellipse cx={cx} cy={cy - r * 0.58} rx={r * 0.72} ry={r * 0.4} fill="#3B2417" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#3B2417'), (s, cx, cy, r) => _smirk(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.22} ${cy + r * 0.18} L${cx} ${cy + r * 0.22} L${cx + r * 0.22} ${cy + r * 0.18}`} fill="none" stroke="#3B2417" strokeWidth={r * 0.07} strokeLinecap="round" /><path d={`M${cx - r * 0.18} ${cy + r * 0.28} Q${cx} ${cy + r * 0.42} ${cx + r * 0.18} ${cy + r * 0.28}`} fill="#3B2417" opacity={0.5} /></>) },
  { id: 'face-13', label: 'Yuki', svgFn: (s) => _f(s, '#E8F5E9', '#FBECD4', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.52} rx={r * 0.85} ry={r * 0.5} fill="#1A1110" /><path d={`M${cx - r * 0.82} ${cy - r * 0.25} Q${cx - r * 0.7} ${cy + r * 0.3} ${cx - r * 0.55} ${cy + r * 0.65}`} stroke="#1A1110" strokeWidth={r * 0.22} fill="none" strokeLinecap="round" /><path d={`M${cx + r * 0.82} ${cy - r * 0.25} Q${cx + r * 0.7} ${cy + r * 0.3} ${cx + r * 0.55} ${cy + r * 0.65}`} stroke="#1A1110" strokeWidth={r * 0.22} fill="none" strokeLinecap="round" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <circle cx={cx + r * 0.4} cy={cy - r * 0.65} r={r * 0.08} fill="#FF6B6B" />) },
  { id: 'face-14', label: 'Nia', svgFn: (s) => _f(s, '#FFF0F5', '#8D5524', (s, cx, cy, r) => <><circle cx={cx} cy={cy - r * 0.15} r={r * 1.1} fill="#2C1810" /><path d={`M${cx - r * 0.6} ${cy - r * 1.0} Q${cx} ${cy - r * 1.3} ${cx + r * 0.6} ${cy - r * 1.0}`} fill="#2C1810" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _grin(s, cx, cy, r), (s, cx, cy, r) => <><circle cx={cx - r * 0.85} cy={cy + r * 0.1} r={r * 0.07} fill="#FFD700" /><circle cx={cx + r * 0.85} cy={cy + r * 0.1} r={r * 0.07} fill="#FFD700" /></>) },
  { id: 'face-15', label: 'Sven', svgFn: (s) => _f(s, '#E3F2FD', '#F5D0A9', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.58} rx={r * 0.7} ry={r * 0.38} fill="#C4A35A" /><rect x={cx - r * 0.2} y={cy - r * 0.78} width={r * 0.4} height={r * 0.12} fill="#C4A35A" /></>, (s, cx, cy, r) => <>{_eyeDot(s, cx, cy, r, '#4682B4')}{_glasses(s, cx, cy, r)}</>, (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.2} ${cy + r * 0.2} Q${cx} ${cy + r * 0.45} ${cx + r * 0.2} ${cy + r * 0.2}`} fill="#C4A35A" opacity={0.6} /><rect x={cx - r * 0.15} y={cy + r * 0.2} width={r * 0.3} height={r * 0.06} fill="#C4A35A" opacity={0.5} /></>) },
  { id: 'face-16', label: 'Mei', svgFn: (s) => _f(s, '#FCE4EC', '#F1C27D', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.88} ry={r * 0.52} fill="#1A1110" /><rect x={cx - r * 0.85} y={cy - r * 0.18} width={r * 0.22} height={r * 1.3} rx={r * 0.1} fill="#1A1110" /><rect x={cx + r * 0.63} y={cy - r * 0.18} width={r * 0.22} height={r * 1.3} rx={r * 0.1} fill="#1A1110" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <><circle cx={cx - r * 0.35} cy={cy + r * 0.22} r={r * 0.09} fill="rgba(255,150,150,0.35)" /><circle cx={cx + r * 0.35} cy={cy + r * 0.22} r={r * 0.09} fill="rgba(255,150,150,0.35)" /></>) },
  { id: 'face-17', label: 'Kofi', svgFn: (s) => _f(s, '#FFF8E1', '#6F4E37', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.8} ry={r * 0.45} fill="#0D0D0D" /><rect x={cx - r * 0.75} y={cy - r * 0.55} width={r * 1.5} height={r * 0.18} fill="#0D0D0D" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _smirk(s, cx, cy, r), (s, cx, cy, r) => <><path d={`M${cx - r * 0.25} ${cy + r * 0.15} Q${cx - r * 0.2} ${cy + r * 0.5} ${cx} ${cy + r * 0.55} Q${cx + r * 0.2} ${cy + r * 0.5} ${cx + r * 0.25} ${cy + r * 0.15}`} fill="#0D0D0D" opacity={0.85} /></>) },
  { id: 'face-18', label: 'Ingrid', svgFn: (s) => _f(s, '#E0F2F1', '#FFE0BD', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.9} ry={r * 0.55} fill="#E8B87E" /><path d={`M${cx - r * 0.88} ${cy - r * 0.15} Q${cx - r * 0.78} ${cy + r * 0.45} ${cx - r * 0.5} ${cy + r * 0.75}`} stroke="#E8B87E" strokeWidth={r * 0.24} fill="none" strokeLinecap="round" /><path d={`M${cx + r * 0.88} ${cy - r * 0.15} Q${cx + r * 0.78} ${cy + r * 0.45} ${cx + r * 0.5} ${cy + r * 0.75}`} stroke="#E8B87E" strokeWidth={r * 0.24} fill="none" strokeLinecap="round" /><path d={`M${cx - r * 0.55} ${cy - r * 0.72} Q${cx} ${cy - r * 0.88} ${cx + r * 0.55} ${cy - r * 0.72}`} fill="none" stroke="#E8B87E" strokeWidth={r * 0.12} /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2E8B57'), (s, cx, cy, r) => _grin(s, cx, cy, r)) },
]

function CartoonFaceSVG({ face, size = 40 }: { face: CartoonFace; size?: number }) {
  return face.svgFn(size)
}

const AGENT_FACES: CartoonFace[] = [
  { id: 'agent-face-1', label: 'Agent A', svgFn: (s) => _f(s, '#E8EAF6', '#E8D5B7', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.75} ry={r * 0.42} fill="#4A4A4A" /><rect x={cx - r * 0.65} y={cy - r * 0.6} width={r * 1.3} height={r * 0.15} fill="#4A4A4A" /></>, (s, cx, cy, r) => <>{_eyeDot(s, cx, cy, r, '#333')}{_glasses(s, cx, cy, r)}</>, (s, cx, cy, r) => _smirk(s, cx, cy, r)) },
  { id: 'agent-face-2', label: 'Agent B', svgFn: (s) => _f(s, '#FCE4EC', '#8D5524', (s, cx, cy, r) => <circle cx={cx} cy={cy - r * 0.2} r={r * 1.05} fill="#0D0D0D" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _grin(s, cx, cy, r)) },
  { id: 'agent-face-3', label: 'Agent C', svgFn: (s) => _f(s, '#E8F5E9', '#FFDBAC', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.9} ry={r * 0.55} fill="#B22222" /><path d={`M${cx - r * 0.85} ${cy - r * 0.2} Q${cx - r * 0.7} ${cy + r * 0.4} ${cx - r * 0.5} ${cy + r * 0.7}`} stroke="#B22222" strokeWidth={r * 0.25} fill="none" strokeLinecap="round" /><path d={`M${cx + r * 0.85} ${cy - r * 0.2} Q${cx + r * 0.7} ${cy + r * 0.4} ${cx + r * 0.5} ${cy + r * 0.7}`} stroke="#B22222" strokeWidth={r * 0.25} fill="none" strokeLinecap="round" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2E8B57'), (s, cx, cy, r) => _smile(s, cx, cy, r)) },
  { id: 'agent-face-4', label: 'Agent D', svgFn: (s) => _f(s, '#FFF3E0', '#C68642', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.85} ry={r * 0.55} fill="#0D0D0D" /><rect x={cx - r * 0.82} y={cy - r * 0.1} width={r * 0.2} height={r * 1.2} rx={r * 0.08} fill="#0D0D0D" /><rect x={cx + r * 0.62} y={cy - r * 0.1} width={r * 0.2} height={r * 1.2} rx={r * 0.08} fill="#0D0D0D" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r), (s, cx, cy, r) => <circle cx={cx + r * 0.85} cy={cy + r * 0.15} r={r * 0.06} fill="#FFD700" />) },
  { id: 'agent-face-5', label: 'Agent E', svgFn: (s) => _f(s, '#E0F2F1', '#F1C27D', (s, cx, cy, r) => <><ellipse cx={cx} cy={cy - r * 0.5} rx={r * 0.85} ry={r * 0.5} fill="#2F1B14" /><circle cx={cx} cy={cy - r * 0.95} r={r * 0.28} fill="#2F1B14" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#4682B4'), (s, cx, cy, r) => _smile(s, cx, cy, r)) },
  { id: 'agent-face-6', label: 'Agent F', svgFn: (s) => _f(s, '#FBE9E7', '#D2A679', (s, cx, cy, r) => <ellipse cx={cx} cy={cy - r * 0.55} rx={r * 0.78} ry={r * 0.42} fill="#1A1110" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#3B2417'), (s, cx, cy, r) => _grin(s, cx, cy, r), (s, cx, cy, r) => <path d={`M${cx - r * 0.3} ${cy + r * 0.18} Q${cx} ${cy + r * 0.6} ${cx + r * 0.3} ${cy + r * 0.18}`} fill="#1A1110" opacity={0.8} />) },
  { id: 'agent-face-7', label: 'Agent G', svgFn: (s) => _f(s, '#F1F8E9', '#FBE8D3', (s, cx, cy, r) => <><path d={`M${cx - r * 1.05} ${cy - r * 0.3} Q${cx - r * 1.1} ${cy - r * 1.3} ${cx} ${cy - r * 1.35} Q${cx + r * 1.1} ${cy - r * 1.3} ${cx + r * 1.05} ${cy - r * 0.3} L${cx + r * 1.0} ${cy + r * 0.9} Q${cx + r * 0.85} ${cy + r * 1.05} ${cx + r * 0.5} ${cy + r * 1.05} L${cx + r * 0.45} ${cy + r * 0.3} L${cx - r * 0.45} ${cy + r * 0.3} L${cx - r * 0.5} ${cy + r * 1.05} Q${cx - r * 0.85} ${cy + r * 1.05} ${cx - r * 1.0} ${cy + r * 0.9} Z`} fill="#4CAF50" /></>, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#2C1810'), (s, cx, cy, r) => _smile(s, cx, cy, r)) },
  { id: 'agent-face-8', label: 'Agent H', svgFn: (s) => _f(s, '#FFFDE7', '#6F4E37', (s, cx, cy, r) => <ellipse cx={cx} cy={cy - r * 0.58} rx={r * 0.72} ry={r * 0.4} fill="#1A1110" />, (s, cx, cy, r) => _eyeDot(s, cx, cy, r, '#1A1110'), (s, cx, cy, r) => _smirk(s, cx, cy, r), (s, cx, cy, r) => <path d={`M${cx - r * 0.2} ${cy + r * 0.18} L${cx} ${cy + r * 0.22} L${cx + r * 0.2} ${cy + r * 0.18}`} fill="none" stroke="#1A1110" strokeWidth={r * 0.07} strokeLinecap="round" />) },
]

interface RoomAgent {
  id: string; name: string; systemPrompt: string; role: string; description: string
  temperature: number; topP: number; responseLength: string
  trigger: 'mentions' | 'all' | 'proactive'; frequency: string
  interAgentRules: 'reference' | 'independent'; color: string; avatar: string
}

interface RoomUser {
  id: string; name: string; email: string
  role: 'participant' | 'observer' | 'moderator' | 'admin'
}

interface Message {
  id: string; content: string; sender: string; senderType: 'agent' | 'user'
  agentId?: string; timestamp: string; confidence?: number; tone?: string; references?: string[]
}

interface Room {
  id: string; name: string; description: string; visibility: 'public' | 'private'
  status: 'active' | 'archived'; isTemplate: boolean; agents: RoomAgent[]
  users: RoomUser[]; messages: Message[]; createdAt: string; lastActivity: string; cloneCode: string
  allowJoin: boolean; initialMessage: string
  timerDuration: number; timerStartedAt: string | null
}

type ViewType = 'dashboard' | 'room-config' | 'discussion'

function RichTextEditor({ value, onChange, placeholder, rows = 4 }: {
  value: string; onChange: (v: string) => void; placeholder?: string; rows?: number
}) {
  const ref = useRef<HTMLTextAreaElement>(null)

  const applyFormat = (type: string) => {
    const el = ref.current
    if (!el) return
    const start = el.selectionStart
    const end = el.selectionEnd
    const selected = value.slice(start, end)
    const lineStart = value.lastIndexOf('\n', start - 1) + 1
    const lineEnd = value.indexOf('\n', end)
    const line = value.slice(lineStart, lineEnd === -1 ? undefined : lineEnd)

    let newValue = value
    let newCursorStart = start
    let newCursorEnd = end

    if (type === 'bold') {
      const replacement = `**${selected || 'bold text'}**`
      newValue = value.slice(0, start) + replacement + value.slice(end)
      newCursorStart = start + 2
      newCursorEnd = start + 2 + (selected || 'bold text').length
    } else if (type === 'italic') {
      const replacement = `*${selected || 'italic text'}*`
      newValue = value.slice(0, start) + replacement + value.slice(end)
      newCursorStart = start + 1
      newCursorEnd = start + 1 + (selected || 'italic text').length
    } else if (type === 'h1') {
      const stripped = line.replace(/^#+\s*/, '')
      newValue = value.slice(0, lineStart) + `# ${stripped}` + value.slice(lineEnd === -1 ? value.length : lineEnd)
    } else if (type === 'h2') {
      const stripped = line.replace(/^#+\s*/, '')
      newValue = value.slice(0, lineStart) + `## ${stripped}` + value.slice(lineEnd === -1 ? value.length : lineEnd)
    } else if (type === 'bullet') {
      const stripped = line.replace(/^[-*]\s*/, '').replace(/^\d+\.\s*/, '')
      newValue = value.slice(0, lineStart) + `- ${stripped}` + value.slice(lineEnd === -1 ? value.length : lineEnd)
    } else if (type === 'numbered') {
      const stripped = line.replace(/^[-*]\s*/, '').replace(/^\d+\.\s*/, '')
      newValue = value.slice(0, lineStart) + `1. ${stripped}` + value.slice(lineEnd === -1 ? value.length : lineEnd)
    } else if (type === 'hr') {
      const insert = '\n---\n'
      newValue = value.slice(0, end) + insert + value.slice(end)
    }

    onChange(newValue)
    setTimeout(() => {
      if (ref.current) {
        ref.current.focus()
        ref.current.setSelectionRange(newCursorStart, newCursorEnd)
      }
    }, 0)
  }

  const ToolBtn = ({ label, action, title }: { label: string; action: string; title: string }) => (
    <button type="button" title={title} onClick={() => applyFormat(action)}
      className="px-2 py-1 text-xs font-medium hover:bg-muted border-r border-border last:border-r-0 text-foreground/70 hover:text-foreground transition-colors">
      {label}
    </button>
  )

  return (
    <div className="border border-border">
      <div className="flex items-center border-b border-border bg-muted/40">
        <ToolBtn label="B" action="bold" title="Bold" />
        <ToolBtn label="I" action="italic" title="Italic" />
        <div className="w-px h-4 bg-border mx-0.5" />
        <ToolBtn label="H1" action="h1" title="Heading 1" />
        <ToolBtn label="H2" action="h2" title="Heading 2" />
        <div className="w-px h-4 bg-border mx-0.5" />
        <ToolBtn label="• List" action="bullet" title="Bullet list" />
        <ToolBtn label="1. List" action="numbered" title="Numbered list" />
        <div className="w-px h-4 bg-border mx-0.5" />
        <ToolBtn label="─ Line" action="hr" title="Horizontal Line" />
      </div>
      <textarea
        ref={ref}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="w-full p-3 text-sm leading-relaxed bg-background text-foreground resize-y outline-none font-mono placeholder:text-muted-foreground"
      />
    </div>
  )
}

function renderMarkdown(text: string) {
  const lines = text.split('\n')
  const elements: any[] = []
  let i = 0
  while (i < lines.length) {
    const line = lines[i]
    if (line.trim().match(/^[-*_]{3,}$/)) {
      elements.push(<hr key={i} className="border-t-2 border-border my-3" />)
    } else if (line.startsWith('### ')) {
      elements.push(<h3 key={i} className="text-sm font-bold font-serif tracking-tight mt-3 mb-1">{formatInline(line.slice(4))}</h3>)
    } else if (line.startsWith('## ')) {
      elements.push(<h2 key={i} className="text-base font-bold font-serif tracking-tight mt-3 mb-1">{formatInline(line.slice(3))}</h2>)
    } else if (line.startsWith('# ')) {
      elements.push(<h1 key={i} className="text-lg font-bold font-serif tracking-tight mt-3 mb-1">{formatInline(line.slice(2))}</h1>)
    } else if (line.match(/^[\-\*]\s/)) {
      const items = []
      while (i < lines.length && lines[i].match(/^[\-\*]\s/)) {
        items.push(<li key={i} className="ml-4 list-disc text-sm">{formatInline(lines[i].slice(2))}</li>)
        i++
      }
      elements.push(<ul key={`ul-${i}`} className="my-1">{items}</ul>)
      continue
    } else if (line.match(/^\d+\.\s/)) {
      const olItems: any[] = []
      let olIdx = 1
      while (i < lines.length && (lines[i].match(/^\d+\.\s/) || (lines[i].trim() === '' && i + 1 < lines.length && lines[i + 1].match(/^\d+\.\s/)))) {
        if (lines[i].trim() === '') { i++; continue }
        const currentNum = olIdx
        olIdx++
        const lineText = lines[i].replace(/^\d+\.\s/, '')
        olItems.push(<div key={`oli-${i}`} className="flex gap-2 text-sm"><span className="flex-shrink-0 min-w-[1.2em] text-right">{currentNum}.</span><span className="flex-1">{formatInline(lineText)}</span></div>)
        i++
      }
      elements.push(<div key={`ol-${i}`} className="my-1 pl-2 space-y-1">{olItems}</div>)
      continue
    } else if (line.trim() === '') {
      elements.push(<div key={i} className="h-1" />)
    } else {
      elements.push(<p key={i} className="text-sm">{formatInline(line)}</p>)
    }
    i++
  }
  return <div className="space-y-0.5">{elements}</div>
}

function formatInline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/)
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i}>{part.slice(2, -2)}</strong>
    }
    if (part.startsWith('*') && part.endsWith('*')) {
      return <em key={i}>{part.slice(1, -1)}</em>
    }
    return part
  })
}

function formatTime(iso: string) {
  const d = new Date(iso)
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function timeAgo(iso: string) {
  const now = Date.now()
  const then = new Date(iso).getTime()
  const diff = now - then
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}

function getInitial(name: string) {
  return name.charAt(0).toUpperCase()
}


function extractAgentResponseText(result: any): string {
  try {
    if (result?.response?.result?.response) return result.response.result.response
    if (result?.response?.result?.text) return result.response.result.text
    if (result?.response?.result?.message) return result.response.result.message
    if (result?.response?.result?.content) return result.response.result.content
    if (result?.response?.result?.answer) return result.response.result.answer
    if (result?.response?.message) return result.response.message
    if (result?.response?.text) return result.response.text
    if (result?.response?.content) return result.response.content
    if (result?.raw_response) return result.raw_response
    if (result?.response) return typeof result.response === 'string' ? result.response : JSON.stringify(result.response)
    if (result?.text) return result.text
    if (result?.content) return result.content
    if (result?.message) return result.message
    if (typeof result === 'string') return result
    return ''
  } catch { return '' }
}

function extractAgentMetadata(result: any, fallbackName: string, fallbackPersonality: string) {
  const confidence = result?.confidence ?? result?.response?.confidence ?? (0.7 + Math.random() * 0.25)
  const tone = result?.tone ?? result?.response?.tone ?? fallbackPersonality
  const references = result?.references ?? result?.response?.references ?? []
  return { agent_name: fallbackName, confidence: Math.round(confidence * 100) / 100, tone, references }
}

const ALL_AVATAR_FACES = [...CARTOON_FACES, ...AGENT_FACES]

function getAvatarFace(avatarId: string, fallbackId: string): CartoonFace {
  return ALL_AVATAR_FACES.find(f => f.id === avatarId) ?? ALL_AVATAR_FACES.find(f => f.id === fallbackId) ?? AGENT_FACES[0]
}

function AgentAvatar({ agent, size = 'md' }: { agent: RoomAgent; size?: 'sm' | 'md' | 'lg' }) {
  const sizePx = { sm: 28, md: 36, lg: 44 }
  const fallbackIdx = Math.abs(agent.id.split('').reduce((h, c) => ((h << 5) - h) + c.charCodeAt(0), 0)) % AGENT_FACES.length
  const face = getAvatarFace(agent.avatar, AGENT_FACES[fallbackIdx].id)
  return (
    <div data-testid={`avatar-agent-${agent.id}`} className="flex-shrink-0 overflow-hidden" style={{ width: sizePx[size], height: sizePx[size] }}>
      <CartoonFaceSVG face={face} size={sizePx[size]} />
    </div>
  )
}

function UserAvatar({ avatarId, size = 'md' }: { avatarId: string; size?: 'sm' | 'md' | 'lg' }) {
  const face = CARTOON_FACES.find(f => f.id === avatarId) ?? CARTOON_FACES[0]
  const sizePx = { sm: 28, md: 36, lg: 44 }
  return (
    <div className="flex-shrink-0 overflow-hidden" style={{ width: sizePx[size], height: sizePx[size] }}>
      <CartoonFaceSVG face={face} size={sizePx[size]} />
    </div>
  )
}

function PolyLearnLogo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="20" y1="7" x2="5" y2="33" stroke="#1d3461" strokeWidth="2.8" strokeLinecap="round" />
      <line x1="20" y1="7" x2="35" y2="33" stroke="#1d3461" strokeWidth="2.8" strokeLinecap="round" />
      <line x1="5" y1="33" x2="35" y2="33" stroke="#1d3461" strokeWidth="2.8" strokeLinecap="round" />
      <circle cx="20" cy="7" r="5" fill="#f97316" />
      <circle cx="5" cy="33" r="5" fill="#1d3461" />
      <circle cx="35" cy="33" r="5" fill="#3b82f6" />
    </svg>
  )
}

function RoleBadge({ role }: { role: string }) {
  return <Badge variant="outline" className="text-[10px] capitalize">{role}</Badge>
}

function TypingDots({ agentName, agentColor }: { agentName: string; agentColor: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2" data-testid={`typing-${agentName}`}>
      <span className="text-xs font-medium tracking-tight" style={{ color: agentColor }}>{agentName}</span>
      <div className="flex gap-1">
        <span className="w-1.5 h-1.5 bg-muted-foreground/50 animate-bounce [animation-delay:0ms]" style={{ borderRadius: '50%' }} />
        <span className="w-1.5 h-1.5 bg-muted-foreground/50 animate-bounce [animation-delay:150ms]" style={{ borderRadius: '50%' }} />
        <span className="w-1.5 h-1.5 bg-muted-foreground/50 animate-bounce [animation-delay:300ms]" style={{ borderRadius: '50%' }} />
      </div>
    </div>
  )
}

function UserIdentityEntry({ onJoin, onToggleLang }: { onJoin: (name: string, role: 'admin' | 'participant', avatarId: string) => void; onToggleLang: () => void }) {
  const { t, lang } = useLanguage()
  const [name, setName] = useState('')
  const [selectedAvatar, setSelectedAvatar] = useState('')
  const [selectedRole, setSelectedRole] = useState<'admin' | 'participant' | ''>('')
  const [passcode, setPasscode] = useState('')
  const [passcodeError, setPasscodeError] = useState(false)

  const canJoin = name.trim().length >= 2 && name.trim().length <= 30 && selectedAvatar && selectedRole && (selectedRole !== 'admin' || passcode === ADMIN_PASSCODE)

  const handleJoin = () => {
    if (selectedRole === 'admin' && passcode !== ADMIN_PASSCODE) {
      setPasscodeError(true)
      return
    }
    if (canJoin && selectedRole) {
      onJoin(name.trim(), selectedRole, selectedAvatar)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-lg space-y-6">
        <div className="flex justify-end">
          <button
            data-testid="button-login-lang-toggle"
            onClick={onToggleLang}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors border px-2.5 py-1.5"
          >
            <FiGlobe className="w-3.5 h-3.5" />
            {lang === 'en' ? t.arabic : t.english}
          </button>
        </div>
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3 mb-1">
            <PolyLearnLogo size={40} />
            <h1 className="text-3xl font-bold font-serif tracking-tight">
              <span style={{ color: '#1d3461' }}>Poly</span><span style={{ color: '#f97316' }}>Learn</span>
            </h1>
          </div>
          <p className="text-sm text-muted-foreground tracking-tight">{t.platformDesc}</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="font-serif tracking-tight">{t.enterYourName}</CardTitle>
            <CardDescription>{t.joinAs}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="display-name">{t.enterYourName}</Label>
              <Input
                id="display-name"
                data-testid="input-display-name"
                placeholder={t.enterYourName}
                value={name}
                onChange={e => setName(e.target.value)}
                maxLength={30}
              />
            </div>

            <div className="space-y-2">
              <Label>{t.avatar}</Label>
              <div className="grid grid-cols-6 gap-2">
                {CARTOON_FACES.map(face => (
                  <button
                    key={face.id}
                    data-testid={`avatar-${face.id}`}
                    className={cn(
                      'w-full aspect-square cursor-pointer transition-all overflow-hidden',
                      selectedAvatar === face.id ? 'ring-2 ring-foreground ring-offset-2 ring-offset-background' : 'opacity-70'
                    )}
                    onClick={() => setSelectedAvatar(face.id)}
                    title={face.label}
                  >
                    <CartoonFaceSVG face={face} size={60} />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t.joinAs}</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  data-testid="role-admin"
                  className={cn(
                    'border p-4 text-left space-y-1 cursor-pointer transition-all hover-elevate',
                    selectedRole === 'admin' ? 'border-foreground bg-accent' : 'border-border'
                  )}
                  onClick={() => { setSelectedRole('admin'); setPasscodeError(false) }}
                >
                  <div className="flex items-center gap-2">
                    <FiShield className="w-4 h-4" />
                    <span className="font-semibold text-sm tracking-tight capitalize">{t.admin}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{t.configure}</p>
                </button>
                <button
                  data-testid="role-participant"
                  className={cn(
                    'border p-4 text-left space-y-1 cursor-pointer transition-all hover-elevate',
                    selectedRole === 'participant' ? 'border-foreground bg-accent' : 'border-border'
                  )}
                  onClick={() => { setSelectedRole('participant'); setPasscodeError(false) }}
                >
                  <div className="flex items-center gap-2">
                    <FiUserCheck className="w-4 h-4" />
                    <span className="font-semibold text-sm tracking-tight capitalize">{t.participant}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{t.discussion}</p>
                </button>
              </div>
            </div>

            {selectedRole === 'admin' && (
              <div className="space-y-2">
                <Label htmlFor="passcode">{t.passcode}</Label>
                <Input
                  id="passcode"
                  data-testid="input-passcode"
                  type="password"
                  placeholder={t.passcode}
                  value={passcode}
                  onChange={e => { setPasscode(e.target.value); setPasscodeError(false) }}
                />
                {passcodeError && (
                  <p className="text-xs text-destructive flex items-center gap-1">
                    <FiAlertCircle className="w-3 h-3" /> {t.wrongPasscode}
                  </p>
                )}
              </div>
            )}

            <Button
              data-testid="button-join"
              className="w-full"
              disabled={!canJoin}
              onClick={handleJoin}
            >
              <FiLogIn className="w-4 h-4" />
              {t.joinBtn}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function DashboardView({
  rooms, isAdmin, searchQuery, setSearchQuery, userName,
  onCreateRoom, onEnterRoom, onConfigRoom, onCloneRoom, onCloneTemplate, onShowHistory, onDeleteRoom,
}: {
  rooms: Room[]; isAdmin: boolean; searchQuery: string; setSearchQuery: (q: string) => void; userName: string
  onCreateRoom: () => void; onEnterRoom: (room: Room) => void
  onConfigRoom: (room: Room) => void; onCloneRoom: (room: Room) => void; onCloneTemplate: (room: Room) => void
  onShowHistory: (room: Room) => void; onDeleteRoom: (room: Room) => void
}) {
  const { t } = useLanguage()
  const [activeTab, setActiveTab] = useState('templates')
  const matchesSearch = (r: Room) => r.name.toLowerCase().includes(searchQuery.toLowerCase()) || r.description.toLowerCase().includes(searchQuery.toLowerCase())
  const isVisible = (r: Room) => isAdmin || r.visibility === 'public' || r.users.some(u => u.name === userName)

  const [orderedActive, setOrderedActive] = useState<Room[]>([])
  const [orderedTemplates, setOrderedTemplates] = useState<Room[]>([])
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const [dragOverId, setDragOverId] = useState<string | null>(null)
  const suppressClick = useRef(false)

  useEffect(() => {
    setOrderedActive(rooms.filter(r => !r.isTemplate).sort((a, b) => a.sortOrder - b.sortOrder))
    setOrderedTemplates(rooms.filter(r => r.isTemplate).sort((a, b) => a.sortOrder - b.sortOrder))
  }, [rooms])

  const persistOrder = (ordered: Room[]) => {
    fetch('/api/rooms/reorder', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order: ordered.map((r, i) => ({ id: r.id, sortOrder: i })) }),
    })
  }

  const reorder = (fromId: string, toId: string, list: Room[], setList: (r: Room[]) => void) => {
    if (!fromId || fromId === toId) return
    const next = [...list]
    const fromIdx = next.findIndex(r => r.id === fromId)
    const toIdx = next.findIndex(r => r.id === toId)
    if (fromIdx < 0 || toIdx < 0) return
    const [item] = next.splice(fromIdx, 1)
    next.splice(toIdx, 0, item)
    setList(next)
    persistOrder(next)
  }

  const dragHandlers = (room: Room, list: Room[], setList: (r: Room[]) => void) => ({
    draggable: true as const,
    onDragStart: (e: React.DragEvent) => {
      e.dataTransfer.effectAllowed = 'move'
      e.dataTransfer.setData('text/plain', room.id)
      suppressClick.current = false
      setDraggingId(room.id)
    },
    onDragOver: (e: React.DragEvent) => {
      e.preventDefault()
      e.dataTransfer.dropEffect = 'move'
      if (room.id !== draggingId) setDragOverId(room.id)
    },
    onDragLeave: () => setDragOverId(null),
    onDrop: (e: React.DragEvent) => {
      e.preventDefault()
      const fromId = e.dataTransfer.getData('text/plain')
      suppressClick.current = true
      reorder(fromId, room.id, list, setList)
      setDraggingId(null)
      setDragOverId(null)
    },
    onDragEnd: () => {
      setDraggingId(null)
      setDragOverId(null)
    },
  })

  const activeRooms = orderedActive.filter(r => matchesSearch(r) && isVisible(r))
  const templateRooms = orderedTemplates.filter(r => matchesSearch(r))

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-2xl font-bold font-serif tracking-tight" data-testid="text-dashboard-title">{t.discussion}</h1>
        {isAdmin && (
          <Button data-testid="button-create-room" onClick={onCreateRoom}>
            <FiPlus className="w-4 h-4" /> {t.createRoom}
          </Button>
        )}
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <button
          data-testid="tab-templates"
          className={cn(
            'px-4 py-2 text-sm font-medium tracking-tight border transition-all flex items-center gap-2',
            activeTab === 'templates' ? 'bg-foreground text-background' : 'bg-background text-foreground'
          )}
          onClick={() => setActiveTab('templates')}
        >
          {t.templates} <Badge variant={activeTab === 'templates' ? 'secondary' : 'outline'} className="no-default-active-elevate">{templateRooms.length}</Badge>
        </button>
        <button
          data-testid="tab-active-rooms"
          className={cn(
            'px-4 py-2 text-sm font-medium tracking-tight border transition-all flex items-center gap-2',
            activeTab === 'active' ? 'bg-foreground text-background' : 'bg-background text-foreground'
          )}
          onClick={() => setActiveTab('active')}
        >
          {t.activeRooms} <Badge variant={activeTab === 'active' ? 'secondary' : 'outline'} className="no-default-active-elevate">{activeRooms.length}</Badge>
        </button>
      </div>

      <div className="relative">
        <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          data-testid="input-search"
          placeholder={t.searchPlaceholder}
          className="pl-10"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
        />
      </div>

      {activeTab === 'active' && (
        <div className="space-y-3">
          {activeRooms.length === 0 && (
            <div className="text-center py-16 space-y-2">
              <FiMessageSquare className="w-10 h-10 mx-auto text-muted-foreground/40" />
              <p className="text-muted-foreground text-sm">{t.noActiveRooms}</p>
            </div>
          )}
          {activeRooms.map(room => (
            <Card
              key={room.id}
              data-testid={`card-room-${room.id}`}
              {...(isAdmin ? dragHandlers(room, orderedActive, setOrderedActive) : {})}
              className={cn(
                'transition-all select-none',
                isAdmin ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer hover-elevate',
                dragOverId === room.id && draggingId !== room.id ? 'border-t-2 border-t-foreground' : '',
                draggingId === room.id ? 'opacity-40' : ''
              )}
              onClick={() => { if (suppressClick.current) { suppressClick.current = false; return }; onEnterRoom(room) }}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  {isAdmin && (
                    <div className="flex-shrink-0 mt-0.5 text-muted-foreground/40 cursor-grab" data-testid={`drag-handle-${room.id}`}>
                      <FiMenu className="w-4 h-4" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold font-serif tracking-tight">{room.name}</h3>
                      <div className={cn('w-2 h-2 flex-shrink-0', room.status === 'active' ? 'bg-green-500' : 'bg-muted-foreground/40')} style={{ borderRadius: '50%' }} />
                      {room.visibility === 'private' ? <FiLock className="w-3 h-3 text-muted-foreground" /> : <FiGlobe className="w-3 h-3 text-muted-foreground" />}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-1">{room.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1"><FiCpu className="w-3 h-3" /> {room.agents.length} {t.agents}</span>
                      <span className="flex items-center gap-1"><FiUsers className="w-3 h-3" /> {room.users.length} {t.users}</span>
                      <span className="flex items-center gap-1"><FiClock className="w-3 h-3" /> {timeAgo(room.lastActivity)}</span>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {room.agents.map(agent => (
                        <div key={agent.id} className="flex items-center gap-1">
                          <div className="w-2.5 h-2.5 flex-shrink-0" style={{ backgroundColor: agent.color, borderRadius: '50%' }} />
                          <span className="text-xs text-muted-foreground">{agent.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); onCloneRoom(room) }} data-testid={`button-clone-${room.id}`}>
                      <FiCopy className="w-4 h-4" />
                    </Button>
                    {isAdmin && (
                      <>
                        <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); onShowHistory(room) }} data-testid={`button-history-${room.id}`}>
                          <FiClock className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); onConfigRoom(room) }} data-testid={`button-config-${room.id}`}>
                          <FiSettings className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive" onClick={e => { e.stopPropagation(); onDeleteRoom(room) }} data-testid={`button-delete-${room.id}`}>
                          <FiTrash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {activeTab === 'templates' && (
        <div className="space-y-3">
          {templateRooms.length === 0 && (
            <div className="text-center py-16 space-y-2">
              <FiLayout className="w-10 h-10 mx-auto text-muted-foreground/40" />
              <p className="text-muted-foreground text-sm">{t.noTemplates}</p>
            </div>
          )}
          {templateRooms.map(room => (
            <Card
              key={room.id}
              data-testid={`card-template-${room.id}`}
              {...(isAdmin ? dragHandlers(room, orderedTemplates, setOrderedTemplates) : {})}
              className={cn(
                'border-dashed transition-all select-none',
                isAdmin ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer hover-elevate',
                dragOverId === room.id && draggingId !== room.id ? 'border-t-2 border-t-foreground border-solid' : '',
                draggingId === room.id ? 'opacity-40' : ''
              )}
              onClick={() => { if (suppressClick.current) { suppressClick.current = false; return }; onCloneRoom(room) }}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  {isAdmin && (
                    <div className="flex-shrink-0 mt-0.5 text-muted-foreground/40 cursor-grab" data-testid={`drag-handle-template-${room.id}`}>
                      <FiMenu className="w-4 h-4" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold font-serif tracking-tight">{room.name}</h3>
                      <Badge variant="outline" className="text-[10px] no-default-active-elevate" style={{ color: 'hsl(0, 70%, 55%)' }}>
                        <FiLayout className="w-3 h-3 mr-1" /> {t.template}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-1">{room.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1"><FiCpu className="w-3 h-3" /> {room.agents.length} {t.agents}</span>
                      <span>Blueprint</span>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {room.agents.map(agent => (
                        <div key={agent.id} className="flex items-center gap-1">
                          <div className="w-2.5 h-2.5 flex-shrink-0" style={{ backgroundColor: agent.color, borderRadius: '50%' }} />
                          <span className="text-xs text-muted-foreground">{agent.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button variant="outline" size="sm" onClick={e => { e.stopPropagation(); onCloneRoom(room) }} data-testid={`button-use-template-${room.id}`}>
                      {t.cloneTemplate}
                    </Button>
                    {isAdmin && (
                      <>
                        <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); onCloneTemplate(room) }} data-testid={`button-clone-template-${room.id}`} title="Clone Template">
                          <FiCopy className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); onConfigRoom(room) }} data-testid={`button-config-template-${room.id}`}>
                          <FiSettings className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive" onClick={e => { e.stopPropagation(); onDeleteRoom(room) }} data-testid={`button-delete-template-${room.id}`}>
                          <FiTrash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function RoomConfigView({
  room, onSave, onBack, onLaunch,
}: {
  room: Room; onSave: (room: Room) => void; onBack: () => void; onLaunch: (room: Room) => void
}) {
  const [editRoom, setEditRoom] = useState<Room>({ ...room, agents: room.agents.map(a => ({ ...a })), users: room.users.map(u => ({ ...u })) })
  const [selectedAgentId, setSelectedAgentId] = useState(editRoom.agents[0]?.id ?? '')
  const [newUserEmail, setNewUserEmail] = useState('')
  const [newUserRole, setNewUserRole] = useState<RoomUser['role']>('participant')

  const selectedAgent = editRoom.agents.find(a => a.id === selectedAgentId)

  const updateAgent = (updates: Partial<RoomAgent>) => {
    setEditRoom(prev => ({
      ...prev,
      agents: prev.agents.map(a => a.id === selectedAgentId ? { ...a, ...updates } : a)
    }))
  }

  const addAgent = () => {
    const newAgent: RoomAgent = {
      id: generateUUID(), name: 'NewAgent', systemPrompt: 'You are a helpful assistant.',
      role: 'casual', description: '', temperature: 0.7, topP: 0.9, responseLength: 'medium',
      trigger: 'mentions', frequency: 'every-message', interAgentRules: 'reference',
      color: AGENT_COLORS[editRoom.agents.length % AGENT_COLORS.length], avatar: '',
    }
    setEditRoom(prev => ({ ...prev, agents: [...prev.agents, newAgent] }))
    setSelectedAgentId(newAgent.id)
  }

  const removeAgent = (id: string) => {
    setEditRoom(prev => {
      const agents = prev.agents.filter(a => a.id !== id)
      if (selectedAgentId === id) setSelectedAgentId(agents[0]?.id ?? '')
      return { ...prev, agents }
    })
  }

  const addUser = () => {
    if (!newUserEmail.trim()) return
    const newUser: RoomUser = { id: generateUUID(), name: newUserEmail.split('@')[0], email: newUserEmail, role: newUserRole }
    setEditRoom(prev => ({ ...prev, users: [...prev.users, newUser] }))
    setNewUserEmail('')
  }

  const removeUser = (id: string) => {
    setEditRoom(prev => ({ ...prev, users: prev.users.filter(u => u.id !== id) }))
  }

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Button size="icon" variant="ghost" onClick={onBack} data-testid="button-config-back">
          <FiArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-2xl font-bold font-serif tracking-tight">
          Configure {editRoom.isTemplate ? 'Template' : 'Room'}
        </h1>
      </div>

      <Tabs defaultValue="agents">
        <TabsList>
          <TabsTrigger value="agents" data-testid="tab-agents">Agents</TabsTrigger>
          {!editRoom.isTemplate && <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>}
          <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="agents" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Agents</Label>
                <Button size="sm" variant="outline" onClick={addAgent} data-testid="button-add-agent">
                  <FiPlus className="w-3 h-3" /> Add
                </Button>
              </div>
              <div className="space-y-1">
                {editRoom.agents.map(agent => (
                  <div
                    key={agent.id}
                    data-testid={`agent-item-${agent.id}`}
                    className={cn(
                      'flex items-center gap-2 p-2 cursor-pointer border transition-all',
                      selectedAgentId === agent.id ? 'border-foreground bg-accent' : 'border-transparent'
                    )}
                    onClick={() => setSelectedAgentId(agent.id)}
                  >
                    <AgentAvatar agent={agent} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium tracking-tight truncate">{agent.name}</p>
                      <div className="flex items-center gap-1 flex-wrap">
                        <RoleBadge role={agent.role} />
                        <span className="text-[10px] text-muted-foreground">{agent.trigger}</span>
                      </div>
                    </div>
                    <Button size="icon" variant="ghost" onClick={e => { e.stopPropagation(); removeAgent(agent.id) }} data-testid={`button-remove-agent-${agent.id}`}>
                      <FiTrash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2">
              {selectedAgent ? (
                <Card>
                  <CardContent className="p-4 space-y-4">
                    <div className="space-y-2">
                      <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Avatar</Label>
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <AgentAvatar agent={selectedAgent} size="lg" />
                          <p className="text-xs text-muted-foreground">{selectedAgent.avatar ? ALL_AVATAR_FACES.find(f => f.id === selectedAgent.avatar)?.label : 'Click below to pick'}</p>
                        </div>
                        <div className="grid grid-cols-10 gap-1">
                          {ALL_AVATAR_FACES.map(face => (
                            <button
                              key={face.id}
                              data-testid={`avatar-option-${face.id}`}
                              className={cn('w-8 h-8 cursor-pointer transition-all overflow-hidden',
                                selectedAgent.avatar === face.id ? 'ring-2 ring-foreground ring-offset-1 ring-offset-background' : 'opacity-60 hover:opacity-100'
                              )}
                              onClick={() => updateAgent({ avatar: face.id })}
                              title={face.label}
                            >
                              <CartoonFaceSVG face={face} size={32} />
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label htmlFor="agent-name">Name</Label>
                        <Input id="agent-name" data-testid="input-agent-name" value={selectedAgent.name} onChange={e => updateAgent({ name: e.target.value })} />
                      </div>
                      <div className="space-y-1">
                        <Label>Role</Label>
                        <Select value={selectedAgent.role} onValueChange={v => updateAgent({ role: v })}>
                          <SelectTrigger data-testid="select-role"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {ROLES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="agent-description">Description <span className="text-muted-foreground font-normal">(shown to users in the room)</span></Label>
                      <Textarea id="agent-description" data-testid="input-agent-description" value={selectedAgent.description} onChange={e => updateAgent({ description: e.target.value })} rows={2} placeholder="Briefly describe what this agent does and its perspective..." />
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="system-prompt">System Prompt</Label>
                      <Textarea id="system-prompt" data-testid="input-system-prompt" value={selectedAgent.systemPrompt} onChange={e => updateAgent({ systemPrompt: e.target.value })} rows={3} />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label>Temperature: {selectedAgent.temperature.toFixed(1)}</Label>
                        <Slider data-testid="slider-temperature" min={0} max={1} step={0.1} value={[selectedAgent.temperature]} onValueChange={([v]) => updateAgent({ temperature: v })} />
                      </div>
                      <div className="space-y-1">
                        <Label>Top P: {selectedAgent.topP.toFixed(2)}</Label>
                        <Slider data-testid="slider-top-p" min={0} max={1} step={0.05} value={[selectedAgent.topP]} onValueChange={([v]) => updateAgent({ topP: v })} />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label>Response Length</Label>
                        <Select value={selectedAgent.responseLength} onValueChange={v => updateAgent({ responseLength: v })}>
                          <SelectTrigger data-testid="select-response-length"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {RESPONSE_LENGTHS.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label>Frequency</Label>
                        <Select value={selectedAgent.frequency} onValueChange={v => updateAgent({ frequency: v })}>
                          <SelectTrigger data-testid="select-frequency"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {FREQUENCIES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Trigger Rules</Label>
                      <RadioGroup value={selectedAgent.trigger} onValueChange={v => updateAgent({ trigger: v as RoomAgent['trigger'] })}>
                        <div className="flex items-center gap-2"><RadioGroupItem value="mentions" id="t-mentions" /><Label htmlFor="t-mentions" className="text-sm font-normal">Mentions only</Label></div>
                        <div className="flex items-center gap-2"><RadioGroupItem value="all" id="t-all" /><Label htmlFor="t-all" className="text-sm font-normal">All messages</Label></div>
                        <div className="flex items-center gap-2"><RadioGroupItem value="proactive" id="t-proactive" /><Label htmlFor="t-proactive" className="text-sm font-normal">Proactive</Label></div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label>Inter-Agent Rules</Label>
                      <RadioGroup value={selectedAgent.interAgentRules} onValueChange={v => updateAgent({ interAgentRules: v as RoomAgent['interAgentRules'] })}>
                        <div className="flex items-center gap-2"><RadioGroupItem value="reference" id="ia-ref" /><Label htmlFor="ia-ref" className="text-sm font-normal">Reference other agents</Label></div>
                        <div className="flex items-center gap-2"><RadioGroupItem value="independent" id="ia-ind" /><Label htmlFor="ia-ind" className="text-sm font-normal">Independent</Label></div>
                      </RadioGroup>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="text-center py-16 text-muted-foreground text-sm">
                  <FiCpu className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  Add an agent to configure
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {!editRoom.isTemplate && (
          <TabsContent value="users" className="mt-4 space-y-4">
            <div className="flex items-center gap-2">
              <Input data-testid="input-user-email" placeholder="Email address" value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} className="flex-1" />
              <Select value={newUserRole} onValueChange={v => setNewUserRole(v as RoomUser['role'])}>
                <SelectTrigger className="w-40" data-testid="select-user-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="participant">Participant</SelectItem>
                  <SelectItem value="observer">Observer</SelectItem>
                  <SelectItem value="moderator">Moderator</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={addUser} data-testid="button-add-user"><FiPlus className="w-4 h-4" /> Add</Button>
            </div>
            <div className="space-y-1">
              {editRoom.users.map(user => (
                <div key={user.id} className="flex items-center justify-between gap-2 p-2 border">
                  <div className="flex items-center gap-2">
                    <FiUser className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{user.name}</span>
                    <span className="text-xs text-muted-foreground">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] capitalize no-default-active-elevate">{user.role}</Badge>
                    <Button size="icon" variant="ghost" onClick={() => removeUser(user.id)}>
                      <FiTrash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
              {editRoom.users.length === 0 && (
                <p className="text-center py-8 text-sm text-muted-foreground">No users added yet</p>
              )}
            </div>
          </TabsContent>
        )}

        <TabsContent value="settings" className="mt-4">
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="space-y-1">
                <Label htmlFor="room-name">Room Name</Label>
                <Input id="room-name" data-testid="input-room-name" value={editRoom.name} onChange={e => setEditRoom(prev => ({ ...prev, name: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="room-desc">Description</Label>
                <Textarea id="room-desc" data-testid="input-room-desc" value={editRoom.description} onChange={e => setEditRoom(prev => ({ ...prev, description: e.target.value }))} rows={3} />
              </div>
              <div className="space-y-1">
                <Label>Initial Message</Label>
                <p className="text-[10px] text-muted-foreground">Select text and use the toolbar to format. Shown as the first message when users enter.</p>
                <RichTextEditor
                  value={editRoom.initialMessage}
                  onChange={v => setEditRoom(prev => ({ ...prev, initialMessage: v }))}
                  placeholder="Welcome to this discussion room..."
                  rows={7}
                />
                {editRoom.initialMessage.trim() && (
                  <div className="border border-border/60 p-3 bg-muted/30 mt-1">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">Preview</p>
                    <div className="text-sm leading-relaxed text-foreground">{renderMarkdown(editRoom.initialMessage)}</div>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {editRoom.visibility === 'public' ? <FiGlobe className="w-4 h-4" /> : <FiLock className="w-4 h-4" />}
                  <Label>Public Room</Label>
                </div>
                <Switch
                  data-testid="switch-visibility"
                  checked={editRoom.visibility === 'public'}
                  onCheckedChange={c => setEditRoom(prev => ({ ...prev, visibility: c ? 'public' : 'private' }))}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <FiArchive className="w-4 h-4" />
                  <Label>Active</Label>
                </div>
                <Switch
                  data-testid="switch-status"
                  checked={editRoom.status === 'active'}
                  onCheckedChange={c => setEditRoom(prev => ({ ...prev, status: c ? 'active' : 'archived' }))}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="clone-code">Clone Code</Label>
                <Input id="clone-code" data-testid="input-clone-code" value={editRoom.cloneCode} onChange={e => setEditRoom(prev => ({ ...prev, cloneCode: e.target.value }))} />
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <FiLayout className="w-4 h-4" />
                  <Label>Is Template</Label>
                </div>
                <Switch
                  data-testid="switch-template"
                  checked={editRoom.isTemplate}
                  onCheckedChange={c => setEditRoom(prev => ({ ...prev, isTemplate: c }))}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <FiUsers className="w-4 h-4" />
                  <div>
                    <Label>Allow Join on Clone</Label>
                    <p className="text-[10px] text-muted-foreground">Users who clone this room can join and start chatting immediately</p>
                  </div>
                </div>
                <Switch
                  data-testid="switch-allow-join"
                  checked={editRoom.allowJoin}
                  onCheckedChange={c => setEditRoom(prev => ({ ...prev, allowJoin: c }))}
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <FiClock className="w-4 h-4" />
                  <Label htmlFor="timer-duration">Room Timer (minutes)</Label>
                </div>
                <p className="text-[10px] text-muted-foreground">Countdown timer shown in the discussion. Set to 0 to disable.</p>
                <Input
                  id="timer-duration"
                  data-testid="input-timer-duration"
                  type="number"
                  min={0}
                  max={480}
                  value={editRoom.timerDuration}
                  onChange={e => setEditRoom(prev => ({ ...prev, timerDuration: Math.max(0, parseInt(e.target.value) || 0) }))}
                  className="w-32"
                />
              </div>

              <Separator />

              <div className="flex items-center gap-2 flex-wrap">
                <Button onClick={() => onSave(editRoom)} data-testid="button-save-room">Save Changes</Button>
                <Button variant="outline" onClick={() => onLaunch(editRoom)} data-testid="button-launch-discussion">
                  <FiMessageSquare className="w-4 h-4" /> Launch Discussion
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function DiscussionView({
  room, userName, userRole, userAvatar, onBack, onUpdateRoom, isAdmin, isDark, onToggleDark,
}: {
  room: Room; userName: string; userRole: string; userAvatar: string
  onBack: () => void; onUpdateRoom: (room: Room) => void; isAdmin: boolean
  isDark: boolean; onToggleDark: () => void
}) {
  const [input, setInput] = useState('')
  const [typingAgents, setTypingAgents] = useState<string[]>([])
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [emojiTab, setEmojiTab] = useState(0)
  const [showSidebar, setShowSidebar] = useState(true)
  const [mentionQuery, setMentionQuery] = useState<string | null>(null)
  const [mentionIndex, setMentionIndex] = useState(0)
  const [timeLeft, setTimeLeft] = useState<number | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const roomRef = useRef(room)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const messageCountRef = useRef(0)
  const lastProactiveTimeRef = useRef<Record<string, number>>({})

  useEffect(() => {
    if (room.timerDuration <= 0) { setTimeLeft(null); return }
    if (!room.timerStartedAt) {
      const updated = { ...room, timerStartedAt: new Date().toISOString() }
      onUpdateRoom(updated)
      fetch(`/api/rooms/${room.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      }).catch(() => {})
      setTimeLeft(room.timerDuration * 60)
      return
    }
    const elapsed = Math.floor((Date.now() - new Date(room.timerStartedAt).getTime()) / 1000)
    const remaining = Math.max(0, room.timerDuration * 60 - elapsed)
    setTimeLeft(remaining)
  }, [room.timerDuration, room.timerStartedAt])

  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0) return
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev === null || prev <= 0) return 0
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [timeLeft !== null && timeLeft > 0])

  const timerExpired = timeLeft !== null && timeLeft <= 0
  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60)
    const s = seconds % 60
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  const mentionSuggestions = mentionQuery !== null
    ? room.agents.filter(a => a.name.toLowerCase().startsWith(mentionQuery.toLowerCase()))
    : []

  const handleInputChange = (value: string) => {
    setInput(value)
    const textarea = textareaRef.current
    if (textarea) {
      const cursorPos = textarea.selectionStart
      const textBefore = value.slice(0, cursorPos)
      const match = textBefore.match(/@(\w*)$/)
      if (match) {
        setMentionQuery(match[1])
        setMentionIndex(0)
      } else {
        setMentionQuery(null)
      }
    } else {
      setMentionQuery(null)
    }
  }

  const insertMention = (agentName: string) => {
    const textarea = textareaRef.current
    if (!textarea) return
    const cursorPos = textarea.selectionStart
    const textBefore = input.slice(0, cursorPos)
    const textAfter = input.slice(cursorPos)
    const match = textBefore.match(/@(\w*)$/)
    if (match) {
      const beforeMention = textBefore.slice(0, match.index)
      const newValue = `${beforeMention}@${agentName} ${textAfter}`
      setInput(newValue)
      setMentionQuery(null)
      setTimeout(() => {
        const newPos = (match.index ?? 0) + agentName.length + 2
        textarea.selectionStart = newPos
        textarea.selectionEnd = newPos
        textarea.focus()
      }, 0)
    }
  }

  useEffect(() => { roomRef.current = room }, [room])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [room.messages, typingAgents])

  const persistMessage = useCallback(async (roomId: string, msg: Message) => {
    try {
      await fetch(`/api/rooms/${roomId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg),
      })
    } catch (err) {
      console.error('Failed to persist message:', err)
    }
  }, [])

  const handleSendMessage = useCallback(async () => {
    if (!input.trim()) return
    const userMsg: Message = {
      id: generateUUID(), content: input.trim(), sender: userName,
      senderType: 'user', timestamp: new Date().toISOString(),
    }

    const updated = { ...roomRef.current, messages: [...roomRef.current.messages, userMsg], lastActivity: new Date().toISOString() }
    roomRef.current = updated
    onUpdateRoom(updated)
    persistMessage(room.id, userMsg)
    const currentInput = input.trim()
    setInput('')

    const mentions = currentInput.match(/@(\w+)/g)?.map(m => m.slice(1)) || []
    const mentionedAgents = room.agents.filter(a => mentions.some(m => m.toLowerCase() === a.name.toLowerCase()))
    messageCountRef.current += 1
    const msgNum = messageCountRef.current

    const shouldFireByFrequency = (agent: typeof room.agents[0]) => {
      if (agent.frequency === 'every-message') return true
      if (agent.frequency === 'every-2nd') return msgNum % 2 === 0
      if (agent.frequency === 'every-3rd') return msgNum % 3 === 0
      if (agent.frequency === 'cooldown-30s') {
        const last = lastProactiveTimeRef.current[agent.id] || 0
        if (Date.now() - last >= 30000) {
          lastProactiveTimeRef.current[agent.id] = Date.now()
          return true
        }
        return false
      }
      return true
    }

    let agentsToCall: typeof room.agents
    if (mentionedAgents.length > 0) {
      agentsToCall = [...mentionedAgents]
      const proactiveExtras = room.agents.filter(a =>
        a.trigger === 'proactive' &&
        !mentionedAgents.some(m => m.id === a.id) &&
        shouldFireByFrequency(a)
      )
      agentsToCall.push(...proactiveExtras)
    } else {
      const allTriggerAgents = room.agents.filter(a => a.trigger === 'all' && shouldFireByFrequency(a))
      const proactiveAgents = room.agents.filter(a => a.trigger === 'proactive' && shouldFireByFrequency(a))
      agentsToCall = [...allTriggerAgents, ...proactiveAgents]
    }

    const otherAgentNames = room.agents.map(a => a.name)
    const userParticipants = room.users.map(u => `${u.name} (${u.role})`)
    const participantList = [
      ...userParticipants,
      ...otherAgentNames.map(n => `${n} (AI agent)`),
    ]

    for (const agent of agentsToCall) {
      setTypingAgents(prev => [...prev, agent.id])
      try {
        const allMessages = roomRef.current.messages
        const otherAgents = room.agents.filter(a => a.id !== agent.id)
        const otherAgentDescriptions = otherAgents.map(a => `- ${a.name}: ${a.role} role`).join('\n')
        const wasMentioned = mentionedAgents.some(m => m.id === agent.id)
        const silenceInstruction = !wasMentioned ? `\n\nIMPORTANT: If the latest message is not relevant to your role or expertise, or if you have nothing meaningful to add, respond with exactly "[SKIP]" and nothing else. Only respond when the conversation is relevant to your instructions.` : ''
        const systemPrompt = `You are ${agent.name}. ${agent.systemPrompt}\n\nRole: ${agent.role}\nResponse length: ${agent.responseLength}\n\nRoom: "${room.name}" — ${room.description || 'No description'}\n\nParticipants in this discussion:\n${participantList.map(p => `- ${p}`).join('\n')}\n\n${otherAgents.length > 0 ? `Other AI agents:\n${otherAgentDescriptions}\n\n` : ''}Stay in character. Respond naturally to the conversation. You are aware of all participants and the full conversation history.\n\nIMPORTANT: Do NOT prefix your response with your name. Do NOT start with "${agent.name}:" — just respond directly with your message content.${silenceInstruction}`
        const userMessages = allMessages.map(m => {
          if (m.senderType === 'agent' && m.sender === agent.name) {
            return { role: 'assistant' as const, content: m.content }
          }
          const senderLabel = m.senderType === 'agent' ? `[${m.sender}]` : m.sender
          return { role: 'user' as const, content: `${senderLabel}: ${m.content}` }
        })

        const result = await callAIAgent(systemPrompt, userMessages, { session_id: `room-${room.id}-agent-${agent.id}`, agentName: agent.name })
        let responseText = extractAgentResponseText(result)
        if (responseText) {
          responseText = responseText.trim()
          const escapedName = agent.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
          const namePrefix = new RegExp(`^${escapedName}\\s*:\\s*`, 'i')
          responseText = responseText.replace(namePrefix, '')
        }
        const metadata = extractAgentMetadata(result, agent.name, agent.role)

        if (responseText && !responseText.trim().includes('[SKIP]')) {
          const agentMsg: Message = {
            id: generateUUID(), content: responseText, sender: agent.name,
            senderType: 'agent', agentId: agent.id, timestamp: new Date().toISOString(),
            confidence: metadata.confidence, tone: metadata.tone, references: metadata.references,
          }
          const latest = { ...roomRef.current, messages: [...roomRef.current.messages, agentMsg], lastActivity: new Date().toISOString() }
          roomRef.current = latest
          onUpdateRoom(latest)
          persistMessage(room.id, agentMsg)
        }
      } catch (e) { console.error(e) }
      setTypingAgents(prev => prev.filter(id => id !== agent.id))
    }
  }, [input, userName, room, onUpdateRoom, persistMessage])

  const insertAgentMention = (agentName: string) => {
    setInput(prev => {
      const trimmed = prev.trimEnd()
      const prefix = trimmed.length > 0 ? trimmed + ' ' : ''
      return `${prefix}@${agentName} `
    })
    setMentionQuery(null)
    setTimeout(() => textareaRef.current?.focus(), 0)
  }

  const insertEmoji = (emoji: string) => {
    setInput(prev => prev + emoji)
    setShowEmojiPicker(false)
    textareaRef.current?.focus()
  }

  const hasText = input.trim().length > 0

  return (
    <div className="flex flex-col h-screen">
      <div className="flex items-center justify-between gap-2 p-3 border-b flex-shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <Button size="icon" variant="ghost" onClick={onBack} data-testid="button-discussion-back">
            <FiArrowLeft className="w-4 h-4" />
          </Button>
          <h2 className="font-bold font-serif tracking-tight truncate" data-testid="text-room-name">{room.name}</h2>
          <Badge variant="outline" className="no-default-active-elevate text-[10px]"><FiCpu className="w-3 h-3 mr-1" /> {room.agents.length}</Badge>
          {timeLeft !== null && (
            <Badge
              variant={timerExpired ? 'destructive' : timeLeft <= 60 ? 'destructive' : 'outline'}
              className={cn('no-default-active-elevate text-[10px] tabular-nums', timeLeft <= 60 && !timerExpired && 'animate-pulse')}
              data-testid="badge-timer"
            >
              <FiClock className="w-3 h-3 mr-1" />
              {timerExpired ? 'Time Up' : formatTimer(timeLeft)}
            </Badge>
          )}
          <Badge variant="outline" className="no-default-active-elevate text-[10px]"><FiUsers className="w-3 h-3 mr-1" /> {room.users.length + 1}</Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button size="icon" variant="ghost" onClick={onToggleDark} data-testid="button-theme-toggle-discussion">
            {isDark ? <FiSun className="w-4 h-4" /> : <FiMoon className="w-4 h-4" />}
          </Button>
          <Button size="icon" variant="ghost" onClick={() => setShowSidebar(!showSidebar)} data-testid="button-toggle-sidebar" className="hidden md:flex">
            <FiUsers className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-1 min-h-0">
        <div className="flex flex-col flex-1 min-w-0">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {room.initialMessage && (
              <div className="border border-border/60 rounded-lg p-4 bg-muted/30" data-testid="initial-message">
                <div className="flex gap-3">
                  <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-accent/20 rounded-md border border-border/40">
                    <FiMessageSquare className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Room Notice</span>
                    <div className="text-sm leading-relaxed font-medium text-foreground [&_p]:text-foreground [&_span]:text-foreground">{renderMarkdown(room.initialMessage)}</div>
                  </div>
                </div>
              </div>
            )}
            {room.messages.map(msg => {
              const isAgent = msg.senderType === 'agent'
              const agent = isAgent ? room.agents.find(a => a.id === msg.agentId) : null
              return (
                <div key={msg.id} data-testid={`message-${msg.id}`} className="flex gap-3">
                  {isAgent && agent ? (
                    <AgentAvatar agent={agent} size="md" />
                  ) : (
                    <UserAvatar avatarId={userAvatar} size="md" />
                  )}
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold tracking-tight" style={isAgent && agent ? { color: agent.color } : {}}>
                        {msg.sender}
                      </span>
                      <span className="text-[10px] text-muted-foreground">{formatTime(msg.timestamp)}</span>
                    </div>
                    <div className="text-sm leading-relaxed">
                      {isAgent ? renderMarkdown(msg.content.replace(new RegExp(`^${msg.sender.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*:\\s*`, 'i'), '')) : <p>{msg.content}</p>}
                    </div>
                    {isAgent && isAdmin && (
                      <div className="flex items-center gap-3 mt-1 flex-wrap">
                        {msg.confidence !== undefined && (
                          <div className="flex items-center gap-1.5">
                            <div className="w-16 h-1.5 bg-muted overflow-hidden">
                              <div className="h-full bg-foreground/40" style={{ width: `${msg.confidence * 100}%` }} />
                            </div>
                            <span className="text-[10px] text-muted-foreground">{Math.round(msg.confidence * 100)}%</span>
                          </div>
                        )}
                        {msg.tone && <Badge variant="outline" className="text-[10px] no-default-active-elevate capitalize">{msg.tone}</Badge>}
                        {msg.references && msg.references.length > 0 && (
                          <span className="text-[10px] text-muted-foreground">Refs: {msg.references.join(', ')}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
            {typingAgents.map(agentId => {
              const agent = room.agents.find(a => a.id === agentId)
              if (!agent) return null
              return <TypingDots key={agentId} agentName={agent.name} agentColor={agent.color} />
            })}
          </div>

          <div className="border-t p-3 flex-shrink-0">
            {timerExpired && (
              <div className="flex items-center gap-2 justify-center py-1 text-xs text-destructive font-medium tracking-tight" data-testid="timer-expired-notice">
                <FiClock className="w-3 h-3" /> Discussion time has ended — you may still participate
              </div>
            )}
            <div className="flex items-end gap-2">
              <div className="flex-1 relative">
                {mentionSuggestions.length > 0 && (
                  <div className="absolute bottom-full left-0 mb-1 bg-popover border w-64 z-50 py-1" data-testid="mention-autocomplete">
                    {mentionSuggestions.map((agent, idx) => (
                      <button
                        key={agent.id}
                        data-testid={`mention-option-${agent.id}`}
                        className={cn(
                          'w-full text-left px-3 py-2 flex items-center gap-2 text-sm cursor-pointer transition-colors',
                          idx === mentionIndex ? 'bg-accent' : 'hover:bg-accent/50'
                        )}
                        onMouseDown={e => { e.preventDefault(); insertMention(agent.name) }}
                      >
                        <div className="w-2.5 h-2.5 flex-shrink-0" style={{ backgroundColor: agent.color, borderRadius: '50%' }} />
                        <span className="font-medium tracking-tight">{agent.name}</span>
                        <span className="text-xs text-muted-foreground ml-auto capitalize">{agent.role}</span>
                      </button>
                    ))}
                  </div>
                )}
                <Textarea
                  ref={textareaRef}
                  data-testid="input-message"
                  placeholder="Type @ to mention agents..."
                  value={input}
                  onChange={e => handleInputChange(e.target.value)}
                  onKeyDown={e => {
                    if (mentionSuggestions.length > 0) {
                      if (e.key === 'ArrowDown') { e.preventDefault(); setMentionIndex(i => (i + 1) % mentionSuggestions.length) }
                      else if (e.key === 'ArrowUp') { e.preventDefault(); setMentionIndex(i => (i - 1 + mentionSuggestions.length) % mentionSuggestions.length) }
                      else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); insertMention(mentionSuggestions[mentionIndex].name) }
                      else if (e.key === 'Escape') { e.preventDefault(); setMentionQuery(null) }
                      return
                    }
                    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage() }
                  }}
                  rows={1}
                  className="resize-none pr-10"
                />
                <div className="absolute right-2 bottom-2">
                  <button
                    data-testid="button-emoji"
                    className="text-muted-foreground cursor-pointer p-1"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  >
                    <FiSmile className="w-4 h-4" />
                  </button>
                </div>
                {showEmojiPicker && (
                  <div className="absolute bottom-full right-0 mb-2 bg-popover border p-3 w-72 z-50" data-testid="emoji-picker">
                    <div className="flex gap-1 mb-2">
                      {EMOJI_CATEGORIES.map((cat, idx) => (
                        <button
                          key={cat.name}
                          className={cn('text-xs px-2 py-1 transition-all', emojiTab === idx ? 'bg-accent font-medium' : '')}
                          onClick={() => setEmojiTab(idx)}
                        >
                          {cat.name}
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-6 gap-1">
                      {EMOJI_CATEGORIES[emojiTab].emojis.map((emoji, i) => (
                        <button
                          key={i}
                          className="text-lg p-1 cursor-pointer text-center"
                          onClick={() => insertEmoji(emoji)}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <Button
                data-testid="button-send"
                size="icon"
                onClick={handleSendMessage}
                disabled={!hasText}
                className={hasText ? '' : 'opacity-50'}
              >
                <FiSend className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {showSidebar && (
          <div className="hidden md:block w-80 border-l flex-shrink-0 overflow-y-auto">
            <div className="p-4 space-y-4">
              <div className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Room Info</h3>
                <Card>
                  <CardContent className="p-3 space-y-2">
                    <p className="text-sm font-semibold font-serif tracking-tight">{room.name}</p>
                    <p className="text-xs text-muted-foreground">{room.description}</p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        {room.visibility === 'public' ? <FiGlobe className="w-3 h-3" /> : <FiLock className="w-3 h-3" />}
                        {room.visibility}
                      </span>
                      <span className="flex items-center gap-1">
                        <div className={cn('w-2 h-2', room.status === 'active' ? 'bg-green-500' : 'bg-muted-foreground/40')} style={{ borderRadius: '50%' }} />
                        {room.status}
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">Created {new Date(room.createdAt).toLocaleDateString()}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Agents ({room.agents.length})</h3>
                {room.agents.map(agent => (
                  <AgentSidebarCard key={agent.id} agent={agent} onMentionInsert={insertAgentMention} />
                ))}
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Users</h3>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 p-1.5">
                    <UserAvatar avatarId={userAvatar} size="sm" />
                    <span className="text-sm tracking-tight">{userName}</span>
                    <Badge variant="outline" className="text-[10px] no-default-active-elevate capitalize ml-auto">{userRole}</Badge>
                  </div>
                  {room.users.filter(u => u.name !== userName).map(user => (
                    <div key={user.id} className="flex items-center gap-2 p-1.5">
                      <div className="w-7 h-7 flex items-center justify-center bg-muted text-muted-foreground flex-shrink-0">
                        <FiUser className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-sm tracking-tight">{user.name}</span>
                      <Badge variant="outline" className="text-[10px] no-default-active-elevate capitalize ml-auto">{user.role}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function AgentSidebarCard({ agent, onMentionInsert }: { agent: RoomAgent; onMentionInsert?: (name: string) => void }) {
  const [open, setOpen] = useState(true)
  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <CollapsibleTrigger asChild>
        <button className="flex items-center gap-2 w-full p-2 text-left cursor-pointer hover-elevate transition-all">
          <div
            className="cursor-pointer hover:opacity-80 transition-opacity"
            data-testid={`button-mention-agent-${agent.id}`}
            onClick={e => { e.stopPropagation(); onMentionInsert?.(agent.name) }}
            title={`Click to mention @${agent.name}`}
          >
            <AgentAvatar agent={agent} size="sm" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium tracking-tight truncate">{agent.name}</p>
          </div>
          {open ? <FiChevronUp className="w-3 h-3 text-muted-foreground" /> : <FiChevronDown className="w-3 h-3 text-muted-foreground" />}
        </button>
      </CollapsibleTrigger>
      <CollapsibleContent>
        {agent.description && (
          <p className="pl-9 pr-2 pb-2 text-xs text-muted-foreground leading-relaxed">{agent.description}</p>
        )}
      </CollapsibleContent>
    </Collapsible>
  )
}

function createSampleData(): Room[] {
  const now = new Date().toISOString()
  const ago = (mins: number) => new Date(Date.now() - mins * 60000).toISOString()

  return [
    {
      id: generateUUID(), name: 'Product Strategy Review', description: 'Quarterly product strategy review with AI advisors',
      visibility: 'private', status: 'active', isTemplate: false, cloneCode: 'strategy2024', allowJoin: true, initialMessage: '', timerDuration: 15, timerStartedAt: null,
      createdAt: ago(1440), lastActivity: ago(15),
      agents: [
        { id: generateUUID(), name: 'ResearchAnalyst', systemPrompt: 'You are a research analyst. Provide data-driven insights and market analysis.', role: 'analytical', description: 'Provides data-driven insights and market analysis to ground the discussion in evidence.', temperature: 0.3, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[0], avatar: '' },
        { id: generateUUID(), name: 'CreativeDirector', systemPrompt: 'You are a creative director. Suggest innovative ideas and creative approaches.', role: 'creative', description: 'Brings imaginative thinking and unconventional ideas to spark new directions.', temperature: 0.8, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[1], avatar: '' },
        { id: generateUUID(), name: 'DevilsAdvocate', systemPrompt: 'You are a devil\'s advocate. Challenge assumptions and point out potential flaws.', role: 'critic', description: 'Challenges assumptions and stress-tests ideas to surface hidden weaknesses.', temperature: 0.6, topP: 0.9, responseLength: 'short', trigger: 'mentions', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[2], avatar: '' },
      ],
      users: [
        { id: generateUUID(), name: 'Sarah Chen', email: 'sarah@example.com', role: 'moderator' },
        { id: generateUUID(), name: 'Marcus Webb', email: 'marcus@example.com', role: 'participant' },
      ],
      messages: [
        { id: generateUUID(), content: 'Let\'s discuss our Q2 product roadmap. What should we prioritize?', sender: 'Sarah Chen', senderType: 'user', timestamp: ago(30) },
        { id: generateUUID(), content: 'Based on current market trends, I recommend focusing on **mobile-first experiences**. Our analytics show a 40% increase in mobile traffic over the past quarter.\n\n- User engagement on mobile is 2.3x higher\n- Conversion rates have improved by 15%\n- Competitor analysis shows a clear gap we can exploit', sender: 'ResearchAnalyst', senderType: 'agent', agentId: '', timestamp: ago(28), confidence: 0.89, tone: 'analytical', references: ['Q1 Analytics Report'] },
        { id: generateUUID(), content: 'What if we went beyond just mobile-first? Imagine an **AI-powered personalization engine** that adapts the entire experience in real-time.\n\n1. Dynamic content based on user behavior\n2. Predictive recommendations\n3. Context-aware UI adjustments', sender: 'CreativeDirector', senderType: 'agent', agentId: '', timestamp: ago(25), confidence: 0.76, tone: 'creative', references: [] },
      ],
    },
    {
      id: generateUUID(), name: 'Tech Architecture Planning', description: 'System architecture discussion for the new platform',
      visibility: 'public', status: 'active', isTemplate: false, cloneCode: 'techarch99', allowJoin: true, initialMessage: '', timerDuration: 15, timerStartedAt: null,
      createdAt: ago(2880), lastActivity: ago(60),
      agents: [
        { id: generateUUID(), name: 'SecurityExpert', systemPrompt: 'You are a cybersecurity expert. Evaluate security implications of every decision.', role: 'analyst', description: 'Evaluates every decision through a security lens to identify risks and vulnerabilities.', temperature: 0.2, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[3], avatar: 'agent-face-1' },
        { id: generateUUID(), name: 'CostOptimizer', systemPrompt: 'You are a cost optimization specialist. Analyze cost-benefit of architectural decisions.', role: 'analytical', description: 'Analyzes the cost-benefit tradeoffs of every architectural choice.', temperature: 0.3, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[4], avatar: '' },
      ],
      users: [
        { id: generateUUID(), name: 'Alex Turner', email: 'alex@example.com', role: 'moderator' },
      ],
      messages: [],
    },
    {
      id: generateUUID(), name: 'Marketing Campaign Brainstorm', description: 'Creative brainstorming for Q3 marketing campaign',
      visibility: 'public', status: 'active', isTemplate: false, cloneCode: 'brand2024', allowJoin: true, initialMessage: '', timerDuration: 15, timerStartedAt: null,
      createdAt: ago(720), lastActivity: ago(120),
      agents: [
        { id: generateUUID(), name: 'BrandStrategist', systemPrompt: 'You are a brand strategist. Focus on brand consistency and market positioning.', role: 'supportive', description: 'Keeps the team anchored to brand identity and strategic positioning.', temperature: 0.5, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[5], avatar: 'agent-face-3' },
      ],
      users: [
        { id: generateUUID(), name: 'Jamie Ross', email: 'jamie@example.com', role: 'participant' },
      ],
      messages: [],
    },
    {
      id: generateUUID(), name: 'Customer Support Team', description: 'Template for customer support discussion rooms with empathy-focused agents',
      visibility: 'public', status: 'active', isTemplate: true, cloneCode: '', allowJoin: true, initialMessage: '', timerDuration: 15, timerStartedAt: null,
      createdAt: ago(4320), lastActivity: ago(4320),
      agents: [
        { id: generateUUID(), name: 'EmpathyResponder', systemPrompt: 'You are an empathetic support agent. Respond with care and understanding.', role: 'supportive', description: 'Responds with warmth and care, ensuring users feel heard and supported.', temperature: 0.4, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[0], avatar: 'face-2' },
        { id: generateUUID(), name: 'KnowledgeExpert', systemPrompt: 'You are a knowledge base expert. Provide accurate technical information.', role: 'analytical', description: 'Delivers accurate, detailed technical information from the knowledge base.', temperature: 0.2, topP: 0.9, responseLength: 'long', trigger: 'mentions', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[1], avatar: 'agent-face-5' },
      ],
      users: [],
      messages: [],
    },
    {
      id: generateUUID(), name: 'Debate Forum', description: 'Template for structured debates with pro/con agents and a moderator',
      visibility: 'public', status: 'active', isTemplate: true, cloneCode: '', allowJoin: true, initialMessage: '', timerDuration: 15, timerStartedAt: null,
      createdAt: ago(4320), lastActivity: ago(4320),
      agents: [
        { id: generateUUID(), name: 'ProAdvocate', systemPrompt: 'You argue in favor of the topic. Present strong supporting arguments.', role: 'formal', description: 'Argues strongly in favor of the topic with structured, compelling reasoning.', temperature: 0.5, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[2], avatar: 'face-8' },
        { id: generateUUID(), name: 'ConCritic', systemPrompt: 'You argue against the topic. Present strong counterarguments.', role: 'critic', description: 'Presents the strongest counterarguments and exposes flaws in the opposing case.', temperature: 0.5, topP: 0.9, responseLength: 'medium', trigger: 'all', frequency: 'every-message', interAgentRules: 'reference', color: AGENT_COLORS[3], avatar: 'face-5' },
        { id: generateUUID(), name: 'DebateModerator', systemPrompt: 'You moderate the debate. Summarize key points and ensure fair discussion.', role: 'facilitator', description: 'Keeps the debate structured, fair, and on track by summarizing and mediating.', temperature: 0.3, topP: 0.9, responseLength: 'medium', trigger: 'proactive', frequency: 'every-2nd', interAgentRules: 'reference', color: AGENT_COLORS[4], avatar: 'agent-face-7' },
      ],
      users: [],
      messages: [],
    },
  ]
}

import React from 'react'

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error?: Error }> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { hasError: false }
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error }
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardContent className="p-6 text-center space-y-3">
              <FiAlertCircle className="w-10 h-10 mx-auto text-destructive" />
              <h2 className="font-bold font-serif tracking-tight">Something went wrong</h2>
              <p className="text-sm text-muted-foreground">{this.state.error?.message}</p>
              <Button onClick={() => this.setState({ hasError: false })}>Try Again</Button>
            </CardContent>
          </Card>
        </div>
      )
    }
    return this.props.children
  }
}

export default function AgentRoomPage() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard')
  const [rooms, setRooms] = useState<Room[]>([])
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [userName, setUserName] = useState('')
  const [userRole, setUserRole] = useState<'admin' | 'participant'>('participant')
  const [userAvatar, setUserAvatar] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [isDark, setIsDark] = useState(false)
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('polylearn-lang') as Lang) || 'en')
  const t = TRANSLATIONS[lang]
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showHistoryModal, setShowHistoryModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [deleteTargetRoom, setDeleteTargetRoom] = useState<Room | null>(null)
  const [showCloneModal, setShowCloneModal] = useState(false)
  const [cloneTarget, setCloneTarget] = useState<Room | null>(null)
  const [cloneCode, setCloneCode] = useState('')
  const [newRoomName, setNewRoomName] = useState('')
  const [newRoomDescription, setNewRoomDescription] = useState('')
  const [newRoomIsTemplate, setNewRoomIsTemplate] = useState(false)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark)
  }, [isDark])

  useEffect(() => {
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr')
    document.documentElement.setAttribute('lang', lang)
    localStorage.setItem('polylearn-lang', lang)
  }, [lang])

  useEffect(() => {
    fetch('/api/rooms')
      .then(res => res.json())
      .then((data: Room[]) => {
        setRooms(data)
        setIsLoading(false)
      })
      .catch(() => setIsLoading(false))
  }, [])

  const isAdmin = userRole === 'admin'

  const handleJoin = (name: string, role: 'admin' | 'participant', avatarId: string) => {
    setUserName(name)
    setUserRole(role)
    setUserAvatar(avatarId)
  }

  const handleLogout = () => {
    setUserName('')
    setUserRole('participant')
    setUserAvatar('')
    setCurrentView('dashboard')
    setSelectedRoom(null)
  }

  const handleCreateRoom = async () => {
    if (!newRoomName.trim()) return
    try {
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newRoomName, description: newRoomDescription,
          visibility: 'public', status: 'active', isTemplate: newRoomIsTemplate,
          cloneCode: '', allowJoin: true, initialMessage: '', timerDuration: 15,
          users: [{ name: userName, email: '', role: isAdmin ? 'moderator' : 'participant' }],
        }),
      })
      const newRoom = await res.json()
      newRoom.agents = newRoom.agents || []
      newRoom.users = newRoom.users || []
      newRoom.messages = newRoom.messages || []
      setRooms(prev => [newRoom, ...prev])
      setShowCreateModal(false)
      setNewRoomName('')
      setNewRoomDescription('')
      setNewRoomIsTemplate(false)
      setSelectedRoom(newRoom)
      setCurrentView('room-config')
    } catch (err) {
      console.error('Failed to create room:', err)
    }
  }

  const handleCloneRoom = (room: Room) => {
    if (room.isTemplate) {
      performClone(room)
    } else {
      setCloneTarget(room)
      setCloneCode('')
      setShowCloneModal(true)
    }
  }

  const handleCloneTemplate = async (room: Room) => {
    try {
      const baseName = `${room.name} (Copy)`
      const existingCopies = rooms.filter(r => r.name === baseName || r.name.startsWith(room.name + ' (Copy') )
      const cloneName = existingCopies.length === 0 ? baseName : `${room.name} (Copy ${existingCopies.length + 1})`
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cloneName,
          description: room.description,
          visibility: room.visibility,
          status: 'active',
          isTemplate: true,
          cloneCode: '',
          allowJoin: room.allowJoin,
          initialMessage: room.initialMessage || '',
          timerDuration: room.timerDuration || 15,
          agents: room.agents.map(({ id, ...a }) => a),
          users: [],
        }),
      })
      const cloned = await res.json()
      cloned.agents = cloned.agents || []
      cloned.users = cloned.users || []
      cloned.messages = cloned.messages || []
      setRooms(prev => [cloned, ...prev])
    } catch (err) {
      console.error('Failed to clone template:', err)
    }
  }

  const performClone = async (room: Room) => {
    try {
      const baseName = `${room.name} - ${userName}`
      const existingVersions = rooms.filter(r => r.name === baseName || r.name.startsWith(baseName + ' v'))
      const cloneName = existingVersions.length === 0 ? baseName : `${baseName} v${existingVersions.length + 1}`
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cloneName,
          description: room.description,
          visibility: 'private',
          status: 'active',
          isTemplate: false,
          cloneCode: '',
          allowJoin: room.allowJoin,
          initialMessage: room.initialMessage || '',
          timerDuration: room.timerDuration || 15,
          agents: room.agents.map(({ id, ...a }) => a),
          users: [{ name: userName, email: '', role: 'moderator' }],
        }),
      })
      const cloned = await res.json()
      cloned.agents = cloned.agents || []
      cloned.users = cloned.users || []
      cloned.messages = cloned.messages || []
      setRooms(prev => [cloned, ...prev])
      setShowCloneModal(false)
      setCloneTarget(null)
      setCloneCode('')
      if (room.allowJoin || isAdmin) {
        setSelectedRoom(cloned)
        setCurrentView('discussion')
      }
    } catch (err) {
      console.error('Failed to clone room:', err)
    }
  }

  const handleCloneSubmit = () => {
    if (!cloneTarget) return
    if (cloneCode === cloneTarget.cloneCode) {
      performClone(cloneTarget)
    }
  }

  const handleUpdateRoom = (updatedRoom: Room) => {
    setRooms(prev => prev.map(r => r.id === updatedRoom.id ? updatedRoom : r))
    setSelectedRoom(updatedRoom)
  }

  const handlePersistRoom = async (updatedRoom: Room) => {
    handleUpdateRoom(updatedRoom)
    try {
      await fetch(`/api/rooms/${updatedRoom.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedRoom),
      })
    } catch (err) {
      console.error('Failed to update room:', err)
    }
  }

  const [historyRoomId, setHistoryRoomId] = useState<string | null>(null)
  const historyRoom = historyRoomId ? rooms.find(r => r.id === historyRoomId) ?? null : null

  if (!userName) {
    return (
      <LanguageContext.Provider value={{ lang, t }}>
        <ErrorBoundary>
          <UserIdentityEntry onJoin={handleJoin} onToggleLang={() => setLang(lang === 'en' ? 'ar' : 'en')} />
        </ErrorBoundary>
      </LanguageContext.Provider>
    )
  }

  return (
    <LanguageContext.Provider value={{ lang, t }}>
    <ErrorBoundary>
      <div className="min-h-screen bg-background text-foreground">
        {currentView !== 'discussion' && (
          <div className="flex items-center justify-between gap-2 p-3 border-b">
            <div className="flex items-center gap-2">
              <PolyLearnLogo size={22} />
              <span className="font-bold font-serif tracking-tight">
                <span style={{ color: '#1d3461' }}>Poly</span><span style={{ color: '#f97316' }}>Learn</span>
              </span>
            </div>
            <div className="flex items-center gap-1">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity" data-testid="button-account-menu">
                    <span className="text-xs text-muted-foreground hidden sm:inline">{userName}</span>
                    <UserAvatar avatarId={userAvatar} size="sm" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-semibold tracking-tight">{userName}</p>
                    <p className="text-xs text-muted-foreground capitalize">{userRole}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setIsDark(!isDark)} className="cursor-pointer" data-testid="button-theme-toggle">
                    {isDark ? <FiSun className="w-4 h-4 mr-2" /> : <FiMoon className="w-4 h-4 mr-2" />}
                    {isDark ? t.lightMode : t.darkMode}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} className="cursor-pointer" data-testid="button-language-toggle">
                    <FiGlobe className="w-4 h-4 mr-2" />
                    {lang === 'en' ? t.switchToArabic : t.switchToEnglish}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer" data-testid="button-logout">
                    <FiLogOut className="w-4 h-4 mr-2" />
                    {t.logOut}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        )}


        {currentView === 'dashboard' && (
          <DashboardView
            rooms={rooms}
            isAdmin={isAdmin}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            userName={userName}
            onCreateRoom={() => setShowCreateModal(true)}
            onEnterRoom={room => {
              setSelectedRoom(room)
              setCurrentView('discussion')
            }}
            onConfigRoom={room => {
              setSelectedRoom(room)
              setCurrentView('room-config')
            }}
            onCloneRoom={handleCloneRoom}
            onCloneTemplate={handleCloneTemplate}
            onShowHistory={room => {
              setHistoryRoomId(room.id)
              setShowHistoryModal(true)
            }}
            onDeleteRoom={room => {
              setDeleteTargetRoom(room)
              setShowDeleteModal(true)
            }}
          />
        )}

        {currentView === 'room-config' && selectedRoom && (
          <RoomConfigView
            room={selectedRoom}
            onSave={updatedRoom => {
              handlePersistRoom(updatedRoom)
              setCurrentView('dashboard')
            }}
            onBack={() => setCurrentView('dashboard')}
            onLaunch={updatedRoom => {
              handlePersistRoom(updatedRoom)
              setCurrentView('discussion')
            }}
          />
        )}

        {currentView === 'discussion' && selectedRoom && (
          <DiscussionView
            room={selectedRoom}
            userName={userName}
            userRole={userRole}
            userAvatar={userAvatar}
            onBack={() => setCurrentView('dashboard')}
            onUpdateRoom={handleUpdateRoom}
            isAdmin={isAdmin}
            isDark={isDark}
            onToggleDark={() => setIsDark(!isDark)}
          />
        )}

        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-serif tracking-tight">{t.createRoomTitle}</DialogTitle>
              <DialogDescription>{t.setupNewRoom}</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="new-room-name">{t.roomName}</Label>
                <Input id="new-room-name" data-testid="input-new-room-name" value={newRoomName} onChange={e => setNewRoomName(e.target.value)} placeholder={t.enterRoomName} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="new-room-desc">{t.description}</Label>
                <Textarea id="new-room-desc" data-testid="input-new-room-desc" value={newRoomDescription} onChange={e => setNewRoomDescription(e.target.value)} placeholder={t.whatsThisRoomAbout} rows={3} />
              </div>
              <div className="flex items-center justify-between">
                <Label>{t.createAsTemplate}</Label>
                <Switch checked={newRoomIsTemplate} onCheckedChange={setNewRoomIsTemplate} data-testid="switch-new-template" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateModal(false)}>{t.cancel}</Button>
              <Button onClick={handleCreateRoom} disabled={!newRoomName.trim()} data-testid="button-confirm-create">{t.confirmCreate}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={showCloneModal} onOpenChange={setShowCloneModal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-serif tracking-tight">
                {cloneTarget?.isTemplate ? t.cloneTemplate : t.cloneRoom}
              </DialogTitle>
              <DialogDescription>
                {cloneTarget?.isTemplate ? `${t.cloneRoomDesc} "${cloneTarget?.name}"` : t.cloneRoomDesc}
              </DialogDescription>
            </DialogHeader>
            {cloneTarget && !cloneTarget.isTemplate && (
              <div className="space-y-1">
                <Label htmlFor="clone-code-input">{t.cloneCode}</Label>
                <Input
                  id="clone-code-input"
                  data-testid="input-clone-code-modal"
                  type="password"
                  value={cloneCode}
                  onChange={e => setCloneCode(e.target.value)}
                  placeholder={t.enterRoomCode}
                />
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCloneModal(false)}>{t.cancel}</Button>
              <Button
                onClick={handleCloneSubmit}
                disabled={!cloneTarget?.isTemplate && cloneCode !== cloneTarget?.cloneCode}
                data-testid="button-confirm-clone"
              >
                {t.confirmClone}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={showHistoryModal} onOpenChange={v => { setShowHistoryModal(v); if (!v) setHistoryRoomId(null) }}>
          <DialogContent className="max-w-2xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="font-serif tracking-tight">{t.roomHistory}</DialogTitle>
              <DialogDescription>{historyRoom?.name}</DialogDescription>
            </DialogHeader>
            <ScrollArea className="h-[60vh]">
              <div className="space-y-3 p-1">
                {historyRoom?.messages.map(msg => (
                  <div key={msg.id} className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold tracking-tight">{msg.sender}</span>
                      <span className="text-[10px] text-muted-foreground">{formatTime(msg.timestamp)}</span>
                      <Badge variant="outline" className="text-[10px] no-default-active-elevate">{msg.senderType}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{msg.content}</p>
                    <Separator />
                  </div>
                ))}
                {(!historyRoom?.messages || historyRoom.messages.length === 0) && (
                  <p className="text-center py-8 text-sm text-muted-foreground">{t.noMessages}</p>
                )}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={showDeleteModal} onOpenChange={v => { setShowDeleteModal(v); if (!v) setDeleteTargetRoom(null) }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-serif tracking-tight">{t.deleteRoom}</DialogTitle>
              <DialogDescription>
                {t.deleteConfirm}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowDeleteModal(false); setDeleteTargetRoom(null) }} data-testid="button-cancel-delete">{t.cancel}</Button>
              <Button variant="destructive" onClick={async () => {
                if (deleteTargetRoom) {
                  try {
                    await fetch(`/api/rooms/${deleteTargetRoom.id}`, { method: 'DELETE' })
                  } catch (err) {
                    console.error('Failed to delete room:', err)
                  }
                  setRooms(prev => prev.filter(r => r.id !== deleteTargetRoom.id))
                  if (selectedRoom?.id === deleteTargetRoom.id) {
                    setSelectedRoom(null)
                    setCurrentView('dashboard')
                  }
                }
                setShowDeleteModal(false)
                setDeleteTargetRoom(null)
              }} data-testid="button-confirm-delete">{t.confirmDelete}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </ErrorBoundary>
    </LanguageContext.Provider>
  )
}
